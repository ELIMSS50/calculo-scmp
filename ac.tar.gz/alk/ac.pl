#!/usr/bin/perl -w
############################################################################
#
#  The Alkalinity Calculator
#  Perl/Tk Version
#  Copyright (c) 2003-2012, Stewart A. Rounds
#
#  Contact:
#    Stewart A. Rounds
#    U.S. Geological Survey
#    2130 SW 5th Avenue
#    Portland, OR 97201
#    sarounds@usgs.gov
#  (I work for the U.S. Geological Survey, but this program was
#   developed on my own time.)
#
#  This program is free software; you may redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
############################################################################

# Turn on for debugging only.  Not needed for routine work.
#use strict;
#use warnings;
#use diagnostics;

# Set the version.  Declare it to be a global variable.
our $version = "2.22Tk // [22-Sep-2012]";

# Print message to screen.
print << "end_of_input";
The Alkalinity Calculator
Version $version
Copyright (c) 2003-2012, Stewart A. Rounds

This is free software and may be redistributed and/or modified
under the terms of the GNU General Public License as published
by the Free Software Foundation.
end_of_input

# Load the calculation subroutines.
require "ac_calcs.pl" or die "unable to load calculation routines\n";

# Load the PostScript subroutines.
require "ac_ps.pl"    or die "unable to load PostScript routines\n";

# Load the interface.
require "ac_gui.pl"   or die "unable to load interface\n";

exit;
