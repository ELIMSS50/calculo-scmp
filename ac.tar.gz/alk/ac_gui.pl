############################################################################
#
#  The Alkalinity Calculator
#  Perl/Tk Interface
#  Copyright (c) 2003-2012, Stewart A. Rounds
#
#  Contact:
#    Stewart A. Rounds
#    U.S. Geological Survey
#    2130 SW 5th Avenue
#    Portland, OR 97201
#    sarounds@usgs.gov
#  (I work for the U.S. Geological Survey, but this program was
#   developed on my own time.)
#
#  This program is free software; you may redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
############################################################################

# Turn on for debugging only.  Not needed for routine work.
#use strict;
#use warnings;
#use diagnostics;

# Use the Perl/Tk toolkit for the GUI.
use Tk;
require Tk::Pane;
require Tk::ROText;

# Use the Win32 modules if it becomes necessary to spawn an internet
#  browser on a Windows system, if needed.  Win32 systems don't have a
#  properly working fork, so the Win32 calls are needed.
if ( $^O eq 'MSWin32' ) {
    require Win32::Process;
}

# Declare the usage of some global variables.
our ($ps_xpagesize, $ps_ypagesize, $ps_rowheight, $ps_fontsize,
     $ps_margin, $ps_ingraph, $psprint, $ps_tname, 
     $ps_x, $ps_y, $ps_col1, $ps_col2, $ps_rspan, 
     @ps_droplines, %ps_twidth,
     @valid_colors, @valid_linetypes, 
     $version, $normal_color, $link_color, $date_time, 
    
     $site_name, $site_id, 
     $collect_date, $collect_time, $temp_input, $spcond_input, 
     $analyst, $analysis_date, $analysis_time, 
     $volume, $filtered, $specify_conc, $acid_conc,
     $lotnumber, $cor_factor, $expiration, $stir_method, 
     $units, $data_order, $data_text, $comments_text, 
     $inc_method, $gran_method, $fit_method, $fixed_method, 
     $bicarb_fixed,  $carb_fixed, 
     $bicarb_endpt2, $carb_endpt2, 
    );
$volume = $temp_input = $spcond_input = "";

# Set aside some local variables.
my ($main, $test_label, $about_window, 
    $pane, $temp_fr, $temp2_fr, $temp_frame, $tw,
    $acid_conc_label, $data_order_label, 
    $conc_label, $conc_entry, $conc_units, 
    $bicarb_ckbtn, $bicarb_label, $bicarb_entry, 
    $carb_ckbtn, $carb_label, $carb_entry, 
    @windowlist, @window, @result_window, @resultlist, 

    $disabled_color, $required_color, $warn_color, $banner_color,
    $background_color, $pane_width, $cursor_shape,
    %status, $datafile, @sd, $browser,
    $row, $content, $width, $height,
    @available_fonts, @usable_fonts, @font_list, @font_array, 
    $available, $usable, $have_symbol_font, $font, $i, 
    $default_font_family, $default_font_size, $default_font,
    $font_family, $font_size, 
    $pts_per_pixel, $screenheight, $screenmmheight, 
   );

# Set some variables.
$normal_color   = "black";
$disabled_color = "grey60";
$required_color = "red";
$warn_color     = "red";
$banner_color   = "#ccccff";
$link_color     = "blue";
$pane_width     = 645;
$cursor_shape   = 'left_ptr';

# Set up the main window.
$main = MainWindow->new;
$main->title("Alkalinity Calculator");
$main->minsize(500,350);
$main->configure(-cursor => $cursor_shape);

# Get available font information.  Systems are guaranteed to have
# Courier, Helvetica, and Times (or surrogate).
@available_fonts = $main->fontFamilies;
foreach $available (@available_fonts) {
    $available = lc($available);
    $have_symbol_font = 1 if ($available eq "symbol");
}
@usable_fonts = ("Albertus",
                 "Application",
                 "Arial", "Arial Narrow", "Arial Unicode MS", "Arial Black",
                 "Bookman Old Style",
                 "Century", "Century Gothic",
                 "CG Times",
                 "Charter",
                 "Comic Sans MS",
                 "Courier", "Courier New",
                 "Futura",
                 "Georgia",
                 "Helvetica",
                #"Itc Avant Garde Gothic", "Itc Souvenir",
                 "Lucida", "Lucidabright",
                 "Lucida Console", "Lucida Sans Unicode",
                #"Lucida Sans", "Lucida Sans Typewriter",
                #"MS Serif", "MS Sans Serif",
                 "New Century Schoolbook",
                 "Palatino", "Palatino Linotype", 
                 "Tahoma",
                 "Times", "Times Roman", "Times New Roman",
                 "Trebuchet MS",
                 "Univers", "Universe",
                #"Utopia",
                 "Verdana",
                 );
foreach $usable (@usable_fonts) {
    if ( &list_match(lc($usable), @available_fonts) > -1 ) {
        push (@font_list, $usable);
    }
}

# Set the default font.  Make some font definitions.
foreach $font ("Helvetica", "Arial", "Times") {
    if ( &list_match($font, @font_list) > -1 ) {
        $default_font_family = $font;
        last;
    }
}
$pts_per_pixel     = $main->scaling();
$screenheight      = $main->screenheight;
$screenmmheight    = $main->screenmmheight;
$default_font_size = int(3. * $screenheight / $screenmmheight / $pts_per_pixel);
$default_font_size = 10 if ( $default_font_size > 10 );
$default_font_size = 7 if ( $default_font_size < 7 );

# Get background color and default font and size.
$test_label = $main->Label(
    -textvariable => " ",
    )->pack(-side => 'bottom', -fill => 'x');
$background_color = $test_label->cget('-background');
@font_array = $test_label->configure('-font');
$test_label->destroy;
for ($i=0; $i<=$#font_array; $i++) {
    if ( $font_array[$i] =~ /{.*}/ ) {
        ($default_font = $font_array[$i]) =~ s/.*{(.*?)}.*/$1/;
        last;
    }
}
if ( !defined( $default_font_family ) ) {
    $default_font_family = $default_font;
    $default_font_family =~ s/{(.+)}.*/$1/;
}
$font_family = $default_font_family;
$font_size   = $default_font_size;

# Create some fonts.
$main->fontCreate('default', -family => $default_font_family,
                             -size   => $default_font_size,
                             -weight => 'normal',
                             -slant  => 'roman',
                             -underline  => 0,
                             -overstrike => 0);
$main->fontCreate('bo',      -family => $default_font_family,
                             -size   => $default_font_size,
                             -weight => 'bold');
$main->fontCreate('it',      -family => $default_font_family,
                             -size   => $default_font_size,
                             -slant  => 'italic');
$main->fontCreate('boit',    -family => $default_font_family,
                             -size   => $default_font_size,
                             -weight => 'bold',
                             -slant  => 'italic');

$main->fontCreate('big',     -family => $default_font_family,
                             -size   => int(1.5*$default_font_size));
$main->fontCreate('bigbo',   -family => $default_font_family,
                             -size   => int(1.5*$default_font_size),
                             -weight => 'bold');
$main->fontCreate('bigit',   -family => $default_font_family,
                             -size   => int(1.5*$default_font_size),
                             -slant  => 'italic');
$main->fontCreate('bigboit', -family => $default_font_family,
                             -size   => int(1.5*$default_font_size),
                             -weight => 'bold',
                             -slant  => 'italic');

$main->fontCreate('med',     -family => $default_font_family,
                             -size   => int(1.25*$default_font_size));
$main->fontCreate('medbo',   -family => $default_font_family,
                             -size   => int(1.25*$default_font_size),
                             -weight => 'bold');
$main->fontCreate('medit',   -family => $default_font_family,
                             -size   => int(1.25*$default_font_size),
                             -slant  => 'italic');
$main->fontCreate('medboit', -family => $default_font_family,
                             -size   => int(1.25*$default_font_size),
                             -weight => 'bold',
                             -slant  => 'italic');

$main->fontCreate('sm',      -family => $default_font_family,
                             -size   => int(0.65*$default_font_size));
$main->fontCreate('smbo',    -family => $default_font_family,
                             -size   => int(0.65*$default_font_size),
                             -weight => 'bold');
$main->fontCreate('smit',    -family => $default_font_family,
                             -size   => int(0.65*$default_font_size),
                             -slant  => 'italic');
$main->fontCreate('smboit',  -family => $default_font_family,
                             -size   => int(0.65*$default_font_size),
                             -weight => 'bold',
                             -slant  => 'italic');

$main->fontCreate('cour',     -family => 'Courier',
                              -size   => $default_font_size);
$main->fontCreate('courbo',   -family => 'Courier',
                              -size   => $default_font_size,
                              -weight => 'bold');
$main->fontCreate('courit',   -family => 'Courier',
                              -size   => $default_font_size,
                              -slant  => 'italic');
$main->fontCreate('courboit', -family => 'Courier',
                              -size   => $default_font_size,
                              -weight => 'bold',
                              -slant  => 'italic');

if ($have_symbol_font) {
    $main->fontCreate('sym',     -family => 'Symbol',
                                 -size   => $default_font_size,
                                 -weight => 'normal',
                                 -slant  => 'roman',
                                 -underline  => 0,
                                 -overstrike => 0);
    $main->fontCreate('symbo',   -family => 'Symbol',
                                 -size   => $default_font_size,
                                 -weight => 'bold');
    $main->fontCreate('symit',   -family => 'Symbol',
                                 -size   => $default_font_size,
                                 -slant  => 'italic');
    $main->fontCreate('symboit', -family => 'Symbol',
                                 -size   => $default_font_size,
                                 -weight => 'bold',
                                 -slant  => 'italic');
}

# Make some fonts for graph legends (Helvetica, 7 pt, bold)
$main->fontCreate('ldefault', -family => 'Helvetica',
                              -size   => 7,
                              -weight => 'bold',
                              -slant  => 'roman',
                              -underline  => 0,
                              -overstrike => 0);
$main->fontCreate('lbo',      -family => 'Helvetica',
                              -size   => 7,
                              -weight => 'bold');
$main->fontCreate('lit',      -family => 'Helvetica',
                              -size   => 7,
                              -weight => 'bold',
                              -slant  => 'italic');
$main->fontCreate('lboit',    -family => 'Helvetica',
                              -size   => 7,
                              -weight => 'bold',
                              -slant  => 'italic');

$main->fontCreate('lbig',     -family => 'Helvetica',
                              -size   => int(1.5* 7),
                              -weight => 'bold');
$main->fontCreate('lbigbo',   -family => 'Helvetica',
                              -size   => int(1.5* 7),
                              -weight => 'bold');
$main->fontCreate('lbigit',   -family => 'Helvetica',
                              -size   => int(1.5* 7),
                              -weight => 'bold',
                              -slant  => 'italic');
$main->fontCreate('lbigboit', -family => 'Helvetica',
                              -size   => int(1.5* 7),
                              -weight => 'bold',
                              -slant  => 'italic');

$main->fontCreate('lmed',     -family => 'Helvetica',
                              -size   => int(1.25* 7),
                              -weight => 'bold');
$main->fontCreate('lmedbo',   -family => 'Helvetica',
                              -size   => int(1.25* 7),
                              -weight => 'bold');
$main->fontCreate('lmedit',   -family => 'Helvetica',
                              -size   => int(1.25* 7),
                              -weight => 'bold',
                              -slant  => 'italic');
$main->fontCreate('lmedboit', -family => 'Helvetica',
                              -size   => int(1.25* 7),
                              -weight => 'bold',
                              -slant  => 'italic');

$main->fontCreate('lsm',      -family => 'Helvetica',
                              -size   => int(0.75* 7),
                              -weight => 'bold');
$main->fontCreate('lsmbo',    -family => 'Helvetica',
                              -size   => int(0.75* 7),
                              -weight => 'bold');
$main->fontCreate('lsmit',    -family => 'Helvetica',
                              -size   => int(0.75* 7),
                              -weight => 'bold',
                              -slant  => 'italic');
$main->fontCreate('lsmboit',  -family => 'Helvetica',
                              -size   => int(0.75* 7),
                              -weight => 'bold',
                              -slant  => 'italic');

$main->fontCreate('lcour',     -family => 'Courier',
                               -size   =>  7,
                               -weight => 'bold');
$main->fontCreate('lcourbo',   -family => 'Courier',
                               -size   =>  7,
                               -weight => 'bold');
$main->fontCreate('lcourit',   -family => 'Courier',
                               -size   =>  7,
                               -weight => 'bold',
                               -slant  => 'italic');
$main->fontCreate('lcourboit', -family => 'Courier',
                               -size   =>  7,
                               -weight => 'bold',
                               -slant  => 'italic');

if ($have_symbol_font) {
    $main->fontCreate('lsym',     -family => 'Symbol',
                                  -size   =>  7,
                                  -weight => 'bold',
                                  -slant  => 'roman',
                                  -underline  => 0,
                                  -overstrike => 0);
    $main->fontCreate('lsymbo',   -family => 'Symbol',
                                  -size   =>  7,
                                  -weight => 'bold');
    $main->fontCreate('lsymit',   -family => 'Symbol',
                                  -size   =>  7,
                                  -weight => 'bold',
                                  -slant  => 'italic');
    $main->fontCreate('lsymboit', -family => 'Symbol',
                                  -size   =>  7,
                                  -weight => 'bold',
                                  -slant  => 'italic');
}


# Menu bar
&make_menubar($main, "main");

# Footer
&footer($main);

# Header
$tw = $main->ROText(
    -height     => 12,
    -relief     => 'flat',
    -font       => 'default',
    -background => $background_color,
    -cursor     => $cursor_shape,
    -wrap       => 'word',
    )->pack(-fill => 'x');
$content = "<img src=\"images/usgs.gif\" width=72 height=20>
<h1>THE ALKALINITY CALCULATOR</h1>
<p>Input acidimetric titration data and other information in the form below.
<strong>Fields shown in <span class=red>red</span> are required.</strong>
The Alkalinity Calculator will analyze the titration curve and calculate the
alkalinity or acid neutralizing capacity (ANC) of the sample using one or
more of <a href=\"methods.html\">several different analysis methods</a>.
Alkalinity is for filtered samples, while ANC is for unfiltered samples.
The results will be displayed in tabular and graphical form.</p>
<p>Send comments, questions, and suggestions to
<a href=\"mailto:sarounds\@usgs.gov\">sarounds\@usgs.gov</a>.  Please send me
any datasets that appear to cause problems for the Alkalinity Calculator.</p>";

(undef, $height) = &parse($tw, $content, 80);
$tw->configure(-height => $height);


# Scrolled pane to hold the form, with optional scrollbars
$pane = $main->Scrolled('Pane',
    -width => $pane_width,
    -height => 0.6 * $screenheight,
    -scrollbars => 'osoe',
    )->pack(-fill => 'both', -expand => 1, -anchor => 'w');

$row = 0;
$pane->Label(
    -text => "Site Information",
    -relief => 'groove',
    -background => $banner_color,
    -font => 'bo',
    )->grid(-row => $row, -column => 0, -columnspan => 4, -sticky => 'ew');

$row++;
$pane->Label(
    -text => "Site Name: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Entry(
    -width => 60,
    -textvariable => \$site_name,
    -font => 'default',
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'w');

$row++;
$pane->Label(
    -text => "Site ID: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Entry(
    -width => 15,
    -textvariable => \$site_id,
    -font => 'default',
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'w');

$row++;
$pane->Label(
    -text => "Collection Date: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Entry(
    -width => 10,
    -textvariable => \$collect_date,
    -font => 'default',
    )->grid(-row => $row, -column => 1, -sticky => 'w');
$pane->Label(
    -text => "Collection Time: ",
    -font => 'default',
    )->grid(-row => $row, -column => 2, -sticky => 'e');
$pane->Entry(
    -width => 5,
    -textvariable => \$collect_time,
    -font => 'default',
    )->grid(-row => $row, -column => 3, -sticky => 'w');

$row++;
$pane->Label(
    -text => "Titration Information",
    -relief => 'groove',
    -background => $banner_color,
    -font => 'bo',
    )->grid(-row => $row, -column => 0, -columnspan => 4, -sticky => 'ew');

$row++;
$pane->Label(
    -text => "Analyst: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Entry(
    -width => 60,
    -textvariable => \$analyst,
    -font => 'default',
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'w');

$row++;
$pane->Label(
    -text => "Analysis Date: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Entry(
    -width => 10,
    -textvariable => \$analysis_date,
    -font => 'default',
    )->grid(-row => $row, -column => 1, -sticky => 'w');
$pane->Label(
    -text => "Analysis Time: ",
    -font => 'default',
    )->grid(-row => $row, -column => 2, -sticky => 'e');
$pane->Entry(
    -width => 5,
    -textvariable => \$analysis_time,
    -font => 'default',
    )->grid(-row => $row, -column => 3, -sticky => 'w');

$row++;
$pane->Label(
    -text => "Sample Temperature: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 1, -sticky => 'w');
$temp_fr->Entry(
    -width => 5,
    -textvariable => \$temp_input,
    -font => 'default',
    )->pack(-side => 'left');
$tw = $temp_fr->ROText(
    -height => 1,
    -width => 14,
    -relief => 'flat',
    -font => 'default',
    -background => $background_color,
    -cursor => $cursor_shape,
    )->pack(-side => 'left');
&parse($tw, "<sup>o</sup>C\&nbsp\;[<a href=\"faq.html\#2.1\">help</a>]");
$pane->Label(
    -text => "Specific Conductance: ",
    -font => 'default',
    )->grid(-row => $row, -column => 2, -sticky => 'e');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 3, -sticky => 'w');
$temp_fr->Entry(
    -width => 5,
    -textvariable => \$spcond_input,
    -font => 'default',
    )->pack(-side => 'left');
$tw = $temp_fr->ROText(
    -height => 1,
    -width => 14,
    -relief => 'flat',
    -font => 'default',
    -background => $background_color,
    -cursor => $cursor_shape,
    )->pack(-side => 'left');
&parse($tw, "\&micro\;S/cm\&nbsp\;[<a href=\"faq.html\#2.1\">help</a>]");

$row++;
$pane->Label(
    -text => "Sample Volume: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 1, -sticky => 'w');
$temp_fr->Entry(
    -width => 5,
    -textvariable => \$volume,
    -font => 'default',
    )->pack(-side => 'left');
$temp_fr->Label(
    -text => "mL",
    -font => 'default',
    )->pack(-side => 'left');
$pane->Label(
    -text => "Filtered Sample?: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 2, -sticky => 'e');
$filtered = "yes";
$pane->Checkbutton(
    -variable => \$filtered,
    -onvalue => "yes",
    -offvalue => "no",
    -takefocus => 0,
    )->grid(-row => $row, -column => 3, -sticky => 'w');

$row++;
$pane->Label(
    -text => "Acid Concentration: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Menubutton(
    -tearoff => 0,
    -takefocus => 1,
    -highlightthickness => 1,
    -indicatoron => 1,
    -relief => 'raised',
    -textvariable => \$acid_conc_label,
    -width => 9,
    -font => 'default',
    -cursor => $cursor_shape,
    -menuitems => [['command', "1.60 N", -font => 'default',
                    -command => sub { &acid_option_sub("1.60") }],
                   ['command', "0.160 N", -font => 'default',
                    -command => sub { &acid_option_sub("0.160") }],
                   ['command', "0.01639 N", -font => 'default',
                    -command => sub { &acid_option_sub("0.01639") }],
                   ['command', "other", -font => 'default',
                    -command => sub { &acid_option_sub("other") }],
                  ],
    )->grid(-row => $row, -column => 1, -sticky => 'w');
$conc_label = $pane->Label(
    -text => " Specify other acid conc.: ",
    -font => 'default',
    )->grid(-row => $row, -column => 2, -sticky => 'e');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 3, -sticky => 'w');
$conc_entry = $temp_fr->Entry(
    -width => 10,
    -state => 'disabled',
    -textvariable => \$specify_conc,
    -font => 'default',
    )->pack(-side => 'left');
$conc_units = $temp_fr->Label(
    -text => "N",
    -font => 'default',
    )->pack(-side => 'left');
&acid_option_sub("0.160");

$row++;
$pane->Label(
    -text => "Acid Lot Number: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Entry(
    -width => 10,
    -textvariable => \$lotnumber,
    -font => 'default',
    )->grid(-row => $row, -column => 1, -sticky => 'w');
$pane->Label(
    -text => " Acid Correction Factor: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 2, -sticky => 'e');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 3, -sticky => 'w');
$cor_factor = "1.01";
$temp_fr->Entry(
    -width => 5,
    -textvariable => \$cor_factor,
    -font => 'default',
    )->pack(-side => 'left');
$tw = $temp_fr->ROText(
    -height => 1,
    -width => 8,
    -relief => 'flat',
    -font => 'default',
    -background => $background_color,
    -cursor => $cursor_shape,
    )->pack(-side => 'left');
&parse($tw, "\&nbsp\;[<a href=\"cor_factor.html\">help</a>]");

$row++;
$pane->Label(
    -text => "Acid Expiration Date: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'e');
$pane->Entry(
    -width => 10,
    -textvariable => \$expiration,
    -font => 'default',
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'w');

$row++;
$pane->Label(
    -text => "Titration Type: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'ne');
$temp_fr = $pane->Frame(
    -relief => 'groove',
    -borderwidth => 2,
    )->grid(-row => $row, -column => 1, -sticky => 'w');
$units = "digital";
$temp_fr->Radiobutton(
    -text => "Digital titrator",
    -value => 'digital',
    -variable => \$units,
    -font => 'default',
    -command => \&set_cor_factor,
    )->pack;
$temp_fr->Radiobutton(
    -text => "Buret titration",
    -value => 'buret',
    -variable => \$units,
    -font => 'default',
    -command => \&set_cor_factor,
    )->pack;
$pane->Label(
    -text => "Stirring Method: ",
    -font => 'default',
    )->grid(-row => $row, -column => 2, -sticky => 'ne', -ipady => 5);
$pane->Menubutton(
    -tearoff => 0,
    -takefocus => 1,
    -highlightthickness => 1,
    -indicatoron => 1,
    -relief => 'raised',
    -textvariable => \$stir_method,
    -width => 8,
    -font => 'default',
    -cursor => $cursor_shape,
    -menuitems => [['command', "magnetic", -font => 'default',
                    -command => sub { $stir_method = "magnetic" }],
                   ['command', "manual", -font => 'default',
                    -command => sub { $stir_method = "manual" }],
                  ],
    )->grid(-row => $row, -column => 3, -sticky => 'nw');
$stir_method = "magnetic";
&set_cor_factor;

$row++;
$pane->Label(
    -text => "Titration Data: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'ne');
$data_text = $pane->Scrolled('Text',
    -width => 12,
    -height => 14,
    -scrollbars => 'osoe',
    -wrap => 'none',
    -font => 'default',
    )->grid(-row => $row, -column => 1, -sticky => 'nsew');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 2, -columnspan => 2, -sticky => 'nw');
$temp_fr->Label(
    -text => "Enter two columns of data:",
    -justify => 'left',
    -font => 'default',
    )->pack(-anchor => 'w');
$temp2_fr = $temp_fr->Frame(
    )->pack(-anchor => 'w');
$temp2_fr->Label(
    -text => "  Order: ",
    -foreground => $required_color,
    -justify => 'left',
    -font => 'default',
    )->pack(-side => 'left');
$temp2_fr->Menubutton(
    -tearoff => 0,
    -takefocus => 1,
    -highlightthickness => 1,
    -indicatoron => 1,
    -relief => 'raised',
    -textvariable => \$data_order_label,
    -width => 39,
    -font => 'default',
    -cursor => $cursor_shape,
    -menuitems => [['command', "pH in 1st column, titrant volume in 2nd",
                    -font => 'default',
                    -command => sub { $data_order = "pH_first";
                                      $data_order_label =
                               "pH in 1st column, titrant volume in 2nd"; }],
                   ['command', "titrant volume in 1st column, pH in 2nd",
                    -font => 'default',
                    -command => sub { $data_order = "vol_first";
                                      $data_order_label =
                               "titrant volume in 1st column, pH in 2nd"; }],
                  ],
    )->pack(-side => 'left');
$data_order = "pH_first";
$data_order_label = "pH in 1st column, titrant volume in 2nd";
$temp_fr->Label(
    -text => "Data must be delimited by a comma or by one or more spaces.
You may \"paste\" your data into this form with the mouse.\n
Digital titrator: (counts)
Titrant volumes are specified in \"counts\" and are assumed
to come from a Hach digital titrator (800 counts per mL).\n
Buret titration: (mL)
Titrant volumes from a buret titration are specified in
milliliters (mL) of acid added.",
    -justify => 'left',
    -font => 'default',
    )->pack(-anchor => 'w');

$row++;
$pane->Label(
    -text => "Comments: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'ne');
$comments_text = $pane->Scrolled('Text',
    -width => 60,
    -height => 5,
    -scrollbars => 'osoe',
    -wrap => 'none',
    -font => 'default',
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'ew');

$row++;
$pane->Label(
    -text => "Titration Analysis",
    -relief => 'groove',
    -background => $banner_color,
    -font => 'bo',
    )->grid(-row => $row, -column => 0, -columnspan => 4, -sticky => 'ew');

$row++;
$pane->Label(
    -text => "Analysis Methods: ",
    -foreground => $required_color,
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'ne');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'nw');
$tw = $temp_fr->ROText(
    -height => 1,
    -relief => 'flat',
    -font => 'default',
    -background => $background_color,
    -cursor => $cursor_shape,
    -wrap => 'word',
    )->grid(-row => 0, -column => 0, -columnspan => 4, -sticky => 'w');
($width, undef) = &parse($tw, "Check one or more of the
  <a href=\"methods.html\">analysis methods</a> you want to use:");
$tw->configure(-width => $width);

$inc_method   = 1;
$gran_method  = 0;
$fit_method   = 0;
$fixed_method = 0;
$temp_fr->Checkbutton(
    -variable => \$inc_method,
    -text => "Inflection point method",
    -font => 'default',
    )->grid(-row => 1, -column => 0, -columnspan => 4, -sticky => 'w');
$temp_fr->Checkbutton(
    -variable => \$gran_method,
    -text => "Gran function plot method",
    -font => 'default',
    )->grid(-row => 2, -column => 0, -columnspan => 4, -sticky => 'w');
$temp_fr->Checkbutton(
    -variable => \$fit_method,
    -text => "Theoretical carbonate titration curve method",
    -font => 'default',
    )->grid(-row => 3, -column => 0, -columnspan => 4, -sticky => 'w');
$temp_fr->Checkbutton(
    -variable => \$fixed_method,
    -text => "Fixed endpoint method:",
    -font => 'default',
    -command => \&fixed_method_sub,
    )->grid(-row => 4, -column => 0, -sticky => 'w');
$carb_fixed    = 1;
$bicarb_fixed  = 1;
$carb_endpt2   = 8.3;
$bicarb_endpt2 = 4.5;
$carb_ckbtn = $temp_fr->Checkbutton(
    -variable => \$carb_fixed,
    -text => "Carbonate:",
    -font => 'default',
    -command => \&set_carb_status,
    )->grid(-row => 4, -column => 1, -sticky => 'w');
$carb_label = $temp_fr->Label(
    -text => "pH = ",
    -font => 'default',
    )->grid(-row => 4, -column => 2, -sticky => 'e');
$carb_entry = $temp_fr->Entry(
    -width => 5,
    -textvariable => \$carb_endpt2,
    -font => 'default',
    )->grid(-row => 4, -column => 3, -sticky => 'w');
$bicarb_ckbtn = $temp_fr->Checkbutton(
    -variable => \$bicarb_fixed,
    -text => "Bicarbonate:",
    -font => 'default',
    -command => \&set_bicarb_status,
    )->grid(-row => 5, -column => 1, -sticky => 'w');
$bicarb_label = $temp_fr->Label(
    -text => "pH = ",
    -font => 'default',
    )->grid(-row => 5, -column => 2, -sticky => 'e');
$bicarb_entry = $temp_fr->Entry(
    -width => 5,
    -textvariable => \$bicarb_endpt2,
    -font => 'default',
    )->grid(-row => 5, -column => 3, -sticky => 'w');
&fixed_method_sub;

$row++;
$pane->Label(
    -text => "Speciation Method: ",
    -font => 'default',
    )->grid(-row => $row, -column => 0, -sticky => 'ne');
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'nw');
$tw = $temp_fr->ROText(
    -height => 4,
    -relief => 'flat',
    -font => 'default',
    -background => $background_color,
    -cursor => $cursor_shape,
    -wrap => 'word',
    )->grid(-row => 0, -column => 0, -sticky => 'w');
($width, undef) = &parse($tw,
 "The <a href=\"methods.html#advanced\">advanced speciation method</a> will be
 used for the calculation of carbonate<br>and bicarbonate concentrations; the
 simple mass-balance speciation method<br>is deprecated and no longer
 available.");
$tw->configure(-width => $width);

$row++;
$temp_fr = $pane->Frame(
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'w');
$temp_fr->Button(
    -text    => "Calculate!",
    -font => 'default',
    -command => sub { $main->Busy(-recurse => 1);
                      $psprint = 0;
                      &calculate;
                      $main->Unbusy },
    )->pack(-side => 'left');
$temp_fr->Button(
    -text    => "Clear Form",
    -font => 'default',
    -command => \&reset_form,
    )->pack(-side => 'left', -padx => 3);

$row++;
$pane->Label(
    -text => "The calculation may take a minute or two.",
    -font => 'default',
    )->grid(-row => $row, -column => 1, -columnspan => 3, -sticky => 'w');

$row++;
$tw = $pane->ROText(
    -height => 6,
    -relief => 'flat',
    -font => 'default',
    -background => $background_color,
    -cursor => $cursor_shape,
    -wrap => 'word',
    )->grid(-row => $row, -column => 0, -columnspan => 4, -sticky => 'nsew');
$content = "<strong>Note:</strong>  The specific conductance is used to
estimate the ionic strength of the sample.  Ionic strength and sample
temperature are used to calculate the equilibrium dissociation constants of
water and carbonic acid, which are then used in the calculation of hydroxide,
carbonate, and bicarbonate concentrations.  If you know the sample's
temperature and specific conductance, please input them.  If these data
are unavailable, default values will be assumed.";
(undef, $height) = &parse($tw, $content, 80);
$tw->configure(-height => $height);


MainLoop;

exit;


sub list_match {
    # Search a list for an exact match using a supplied string.
    # Return its ordinal, or -1 if not found.

    my ($s, @list) = @_;
    my ($i);

    for ($i=0; $i<=$#list; $i++) {
        next if (! defined( $list[$i] ));
        return $i if ($list[$i] eq $s);
    }
    return -1;
}


sub list_search {
    # Search a list using a supplied regular expression.
    # Return its ordinal, or -1 if not found.

    my ($regexp, @list) = @_;
    my ($i);

    for ($i=0; $i<=$#list; $i++) {
        next if (! defined( $list[$i] ));
        return $i if ($list[$i] =~ /$regexp/);
    }
    return -1;
}


sub make_menubar {
    my ($window, $which) = @_;
    my ($menubar, $file_menu, $edit_menu, $help_menu);
    my (@fileitems, @edititems, @helpitems);

    $window->configure(-menu => $menubar = $window->Menu);
    $menubar->configure(-cursor => $cursor_shape);
    if ( $which eq "main" ) {
        @fileitems =
            (
              ['command', "~New",     -command => \&reset_form],
              ['command', "~Open...", -command => \&open_file],
              ['command', "~Save",  -command => sub { &save_file($datafile) }],
              ['command', "Save ~As...", -command => \&save_file],
              "",
              ['command', "E~xit",  -command => sub { exit }],
            );
    } else {
        @fileitems =
            (
              ['command', "~Print", -command => sub { &print_win($which) }],
              ['command', "~Close", -command =>
                                     sub { $main->focusCurrent->destroy }],
              ['command', "E~xit",  -command => sub { exit }],
            );
    }
    $file_menu = $menubar->cascade(
        -label => '~File', -tearoff => 0,
        -menuitems => \@fileitems,
        );

    @edititems =
        (
          ['command', "~Copy",
              -command => sub { $main->eventGenerate('<Control-c>') }],
          ['command', "~Paste",
              -command => sub { $main->eventGenerate('<Control-v>') }],
          ['cascade', "~Font", -tearoff => 0, -menuitems =>
            [
              ['cascade', "~Family", -tearoff => 0, -menuitems =>
                [
                  map ['radiobutton', $_, -value => $_,
                       -variable => \$font_family,
                       -command => sub {\&change_font_family($font_family)}],
                      @font_list,
                ],
              ],
              ['cascade', "~Size", -tearoff => 0, -menuitems =>
                [
                  map ['radiobutton', $_, -value => $_,
                       -variable => \$font_size,
                       -command => sub {\&change_font_size($font_size)}],
                      (6 .. 12),
                ],
              ],
            ],
          ],
        );
    if ( $which ne "main" ) {
        $edititems[0] = $edititems[2];
        $#edititems = 0;
    }
    $edit_menu = $menubar->cascade(
        -label => '~Edit', -tearoff => 0,
        -menuitems => \@edititems,
        );

    @helpitems =
        (
          ['command', "~Version History",
              -command => sub { &follow_link("version_history.html") }],
          ['command', "~Methods",
              -command => sub { &follow_link("methods.html") }],
          ['command', "~Speciation Criteria",
              -command => sub { &follow_link("criteria.html") }],
          ['command', "~Reporting Tips",
              -command => sub { &follow_link("reporting.html") }],
          ['command', "A~cid Lot Info",
              -command => sub { &follow_link("cor_factor.html") }],
          ['command', "~FAQ",
              -command => sub { &follow_link("faq.html") }],
          ['command', "~Download",
              -command => sub { &follow_link("download.html") }],
          ['command', "Mailing ~List",
              -command => sub { &follow_link("http://or.water.usgs.gov/alk/maillist.html") }],
          ['command', "~Printing Results",
              -command => sub { &follow_link("print_results.html") }],
          '',
          ['cascade', "~Examples", -tearoff => 0, -menuitems =>
            [
              ['command', "~Diamond Canal",
                   -command => sub { &open_file("examples/diamond.dat") }],
              ['command', "~Little Abiqua",
                   -command => sub { &open_file("examples/abiqua.dat") }],
              ['command', "~Klamath Lake",
                   -command => sub { &open_file("examples/klamath.dat") }],
              ['command', "~Well Water",
                   -command => sub { &open_file("examples/wellwater.dat") }],
              ['command', "~Theoretical",
                   -command => sub { &open_file("examples/theoretical.dat") }],
            ],
          ],
          '',
          ['command', "~About", -command => \&about ],
        );
    if ( $which ne "main" ) {
        $helpitems[10] = $helpitems[12];
        $#helpitems = 10;
    }
    $help_menu = $menubar->cascade(
        -label => '~Help', -tearoff => 0,
        -menuitems => \@helpitems,
        );
}


sub open_file {
    my ($file) = @_;
    my ($linein, $pos, $key, $value, %input, $comment_flag, $data_flag);

    if ( ! defined ($file) ) {
        $file = $main->getOpenFile(
            -defaultextension => ".dat",
            -filetypes => [ ['Data Files', '.dat'],
                            ['All Files',  '*'],
                          ],
            );
    }
    if ( defined ($file) ) {
        open (IN, $file) or return &pop_up_error("Unable to open\n$file");
        while ( defined( $linein = <IN> ) ) {
            next if ( $linein =~ /^#/ );
            chomp ($linein);
            $linein =~ s/\r$//;  # Strip carriage returns saved by DOS/Win
            if ( $linein =~ /[A-Z][a-zA-Z ]* = / ) {
                $comment_flag = $data_flag = 0;
                $pos   = index($linein, " = ");
                $key   = substr($linein, 0, $pos);
                $value = substr($linein, $pos + 3);
                $input{$key}  = $value;
                $comment_flag = 1 if ( $key eq "Comments" );
                $data_flag    = 1 if ( $key eq "Titration Data" );

            } elsif ( $comment_flag || $data_flag ) {
                $input{$key} .= "\n" if ( $input{$key} ne "" );
                $input{$key} .= $linein;
            }
        }
        $site_name     = $input{"Site Name"};
        $site_id       = $input{"Site ID"};
        $collect_date  = $input{"Collection Date"};
        $collect_time  = $input{"Collection Time"};
        $temp_input    = $input{"Sample Temperature"};
        $temp_input    =~ s/[^+-.eE\d]//g;
        $spcond_input  = $input{"Sample Conductance"};
        $spcond_input  =~ s/[^+-.eE\d]//g;
        $analyst       = $input{"Analyst"};
        $analysis_date = $input{"Analysis Date"};
        $analysis_time = $input{"Analysis Time"};
        $volume        = $input{"Sample Volume"};
        $volume        =~ s/[^+-.eE\d]//g;
        $filtered      = $input{"Filtered Sample"};
        if ( lc($filtered) eq "no" ) {
            $filtered = "no";
        } else {;
            $filtered = "yes";
        }

        $acid_conc = $input{"Acid Concentration"};
        if ( $acid_conc eq "1.60" || $acid_conc eq "1.6"
                                  || $acid_conc == 1.6 ) {
            $acid_conc = "1.60";
            undef $specify_conc;
        } elsif ( $acid_conc eq "0.160" || $acid_conc eq "0.16"
                                        || $acid_conc == 0.16 ) {
            $acid_conc = "0.160";
            undef $specify_conc;
        } elsif ( $acid_conc eq "0.01639" || $acid_conc == 0.1639 ) {
            $acid_conc = "0.01639";
            undef $specify_conc;
        } else {
            $specify_conc = $acid_conc;
            $specify_conc =~ s/[^+-.eE\d]//g;
            $acid_conc    = "other";
        }
        &acid_option_sub($acid_conc);

        $lotnumber   = $input{"Acid Lot Number"};
        $cor_factor  = $input{"Acid Correction Factor"};
        $cor_factor  =~ s/[^+-.eE\d]//g;
        $expiration  = $input{"Acid Expiration Date"};
        $stir_method = $input{"Stirring Method"};
        if ( lc($stir_method) eq "manual" ) {
            $stir_method = "manual";
        } else {;
            $stir_method = "magnetic";
        }
        $units = $input{"Titration Type"};
        if ( lc($units) eq "buret" ) {
            $units = "buret";
        } else {;
            $units = "digital";
        }
        $data_order = $input{"Titration Data Order"};
        if ( lc($data_order) eq "vol_first" ) {
            $data_order       = "vol_first";
            $data_order_label = "titrant volume in 1st column, pH in 2nd";
        } else {
            $data_order       = "pH_first";
            $data_order_label = "pH in 1st column, titrant volume in 2nd";
        }
        $data_text->delete('1.0', 'end');
        $data_text->insert('end', $input{"Titration Data"});
        $comments_text->delete('1.0', 'end');
        $comments_text->insert('end', $input{"Comments"});

        $inc_method   = $gran_method = $fit_method   = 0;
        $fixed_method = $carb_fixed  = $bicarb_fixed = 0;
        $inc_method    = 1 if ( lc($input{"Inflection Point Method"}) eq "yes" );
        $gran_method   = 1 if ( lc($input{"Gran Function Plot Method"}) eq "yes" );
        $fit_method    = 1
         if ( lc($input{"Theoretical Titration Curve Method"}) eq "yes" );
        $fixed_method  = 1 if ( lc($input{"Fixed Endpoint Method"}) eq "yes" );
        $carb_fixed    = 1 if ( lc($input{"Fixed Carbonate Endpoint"}) eq "yes" );
        $bicarb_fixed  = 1 if ( lc($input{"Fixed Bicarbonate Endpoint"}) eq "yes" );
        $carb_endpt2   = $input{"Fixed Carbonate Endpoint Value"};
        $carb_endpt2   =~ s/[^+-.eE\d]//g;
        $bicarb_endpt2 = $input{"Fixed Bicarbonate Endpoint Value"};
        $bicarb_endpt2 =~ s/[^+-.eE\d]//g;
        $datafile      = $file;
        close (IN) or return &pop_up_error("Trouble closing\n$file");
    }
}


sub save_file {
    my ($file) = @_;
    my ($data, $comments);

    if ( defined ($file) ) {
        if ( ! -e $file ) {
            undef $file;
        } else {
            return if ( lc(&pop_up_question("Overwrite $file?")) eq "no" );
        }
    }
    if ( ! defined ($file) ) {
        $file = $main->getSaveFile(
            -defaultextension => ".dat",
            -filetypes => [ ['Data Files', '.dat'],
                            ['All Files',  '*'],
                          ],
            );
    }
    if ( defined ($file) ) {
        open (OUT, ">$file") or return &pop_up_error("Unable to save\n$file");
        print OUT "# Alkalinity Calculator data file, version $version\n";
        print OUT "# File created: ", &get_datetime, "\n";
        print OUT "#\n";
        print OUT "Site Name = $site_name\n";
        print OUT "Site ID = $site_id\n";
        print OUT "Collection Date = $collect_date\n";
        print OUT "Collection Time = $collect_time\n";
        $temp_input =~ s/[^+-.eE\d]//g;
        print OUT "Sample Temperature = $temp_input\n";
        $spcond_input =~ s/[^+-.eE\d]//g;
        print OUT "Sample Conductance = $spcond_input\n";
        print OUT "Analyst = $analyst\n";
        print OUT "Analysis Date = $analysis_date\n";
        print OUT "Analysis Time = $analysis_time\n";
        $volume =~ s/[^+-.eE\d]//g;
        print OUT "Sample Volume = $volume\n";
        print OUT "Filtered Sample = $filtered\n";
        print OUT "Acid Concentration = ";
        if ( $acid_conc eq "other" ) {
            $specify_conc =~ s/[^+-.eE\d]//g;
            print OUT $specify_conc, "\n";
        } else {
            print OUT $acid_conc, "\n";
        }
        print OUT "Acid Lot Number = $lotnumber\n";
        $cor_factor =~ s/[^+-.eE\d]//g;
        print OUT "Acid Correction Factor = $cor_factor\n";
        print OUT "Acid Expiration Date = $expiration\n";
        print OUT "Stirring Method = $stir_method\n";
        print OUT "Titration Type = $units\n";
        print OUT "Titration Data Order = $data_order\n";
        print OUT "Titration Data = \n";
        $data = $data_text->get('1.0', 'end');
        $data =~ s/^\s+//;
        $data =~ s/\s+$//;
        print OUT "$data\n";
        $comments = $comments_text->get('1.0', 'end');
        $comments =~ s/^\s+//;
        $comments =~ s/\s+$//;
        print OUT "Comments = $comments\n";

        print OUT "Inflection Point Method = ";
        if ($inc_method) { print OUT "yes\n" } else { print OUT "no\n" }
        print OUT "Gran Function Plot Method = ";
        if ($gran_method) { print OUT "yes\n" } else { print OUT "no\n" }
        print OUT "Theoretical Titration Curve Method = ";
        if ($fit_method) { print OUT "yes\n" } else { print OUT "no\n" }
        print OUT "Fixed Endpoint Method = ";
        if ($fixed_method) { print OUT "yes\n" } else { print OUT "no\n" }
        print OUT "Fixed Carbonate Endpoint = ";
        if ($carb_fixed) { print OUT "yes\n" } else { print OUT "no\n" }
        $carb_endpt2 =~ s/[^+-.eE\d]//g;
        print OUT "Fixed Carbonate Endpoint Value = $carb_endpt2\n";
        print OUT "Fixed Bicarbonate Endpoint = ";
        if ($bicarb_fixed) { print OUT "yes\n" } else { print OUT "no\n" }
        $bicarb_endpt2 =~ s/[^+-.eE\d]//g;
        print OUT "Fixed Bicarbonate Endpoint Value = $bicarb_endpt2\n";
        print OUT "Advanced Speciation Method = yes\n";
        print OUT "Simple Speciation Method = no\n";
        $datafile = $file;
        close (OUT) or return &pop_up_error("Trouble closing\n$file");
    }
}


sub save_data {
    my ($i) = @_;
    my ($data, $comments);

    $sd[$i]{'date_time'}        = $date_time;
    $sd[$i]{'site_name'}        = $site_name;
    $sd[$i]{'site_id'}          = $site_id;
    $sd[$i]{'collect_date'}     = $collect_date;
    $sd[$i]{'collect_time'}     = $collect_time;
    $temp_input                 =~ s/[^+-.eE\d]//g;
    $sd[$i]{'temp_input'}       = $temp_input;
    $spcond_input               =~ s/[^+-.eE\d]//g;
    $sd[$i]{'spcond_input'}     = $spcond_input;
    $sd[$i]{'analyst'}          = $analyst;
    $sd[$i]{'analysis_date'}    = $analysis_date;
    $sd[$i]{'analysis_time'}    = $analysis_time;
    $volume                     =~ s/[^+-.eE\d]//g;
    $sd[$i]{'volume'}           = $volume;
    $sd[$i]{'filtered'}         = $filtered;
    $sd[$i]{'acid_conc'}        = $acid_conc;
    $specify_conc               =~ s/[^+-.eE\d]//g if (defined ($specify_conc));
    $sd[$i]{'specify_conc'}     = $specify_conc;
    $sd[$i]{'lotnumber'}        = $lotnumber;
    $cor_factor                 =~ s/[^+-.eE\d]//g;
    $sd[$i]{'cor_factor'}       = $cor_factor;
    $sd[$i]{'expiration'}       = $expiration;
    $sd[$i]{'stir_method'}      = $stir_method;
    $sd[$i]{'units'}            = $units;
    $sd[$i]{'data_order'}       = $data_order;
    $sd[$i]{'data_order_label'} = $data_order_label;

    $data = $data_text->get('1.0', 'end');
    $data =~ s/^\s+//;
    $data =~ s/\s+$//;
    $sd[$i]{'data'}             = $data;
    $comments = $comments_text->get('1.0', 'end');
    $comments =~ s/^\s+//;
    $comments =~ s/\s+$//;
    $sd[$i]{'comments'}         = $comments;

    $sd[$i]{'inc_method'}       = $inc_method;
    $sd[$i]{'gran_method'}      = $gran_method;
    $sd[$i]{'fit_method'}       = $fit_method;
    $sd[$i]{'fixed_method'}     = $fixed_method;
    $sd[$i]{'carb_fixed'}       = $carb_fixed;
    $sd[$i]{'bicarb_fixed'}     = $bicarb_fixed;
    $sd[$i]{'carb_endpt2'}      = $carb_endpt2;
    $carb_endpt2                =~ s/[^+-.eE\d]//g;
    $sd[$i]{'bicarb_endpt2'}    = $bicarb_endpt2;
    $bicarb_endpt2              =~ s/[^+-.eE\d]//g;
}


sub get_data {
    my ($i) = @_;

    $date_time        = $sd[$i]{'date_time'};
    $site_name        = $sd[$i]{'site_name'};
    $site_id          = $sd[$i]{'site_id'};
    $collect_date     = $sd[$i]{'collect_date'};
    $collect_time     = $sd[$i]{'collect_time'};
    $temp_input       = $sd[$i]{'temp_input'};
    $temp_input       =~ s/[^+-.eE\d]//g;
    $spcond_input     = $sd[$i]{'spcond_input'};
    $spcond_input     =~ s/[^+-.eE\d]//g;
    $analyst          = $sd[$i]{'analyst'};
    $analysis_date    = $sd[$i]{'analysis_date'};
    $analysis_time    = $sd[$i]{'analysis_time'};
    $volume           = $sd[$i]{'volume'};
    $volume           =~ s/[^+-.eE\d]//g;
    $filtered         = $sd[$i]{'filtered'};
    $acid_conc        = $sd[$i]{'acid_conc'};
    $specify_conc     = $sd[$i]{'specify_conc'};
    if ( $acid_conc eq "1.60" || $acid_conc eq "1.6"
                              || $acid_conc == 1.6 ) {
        $acid_conc = "1.60";
        undef $specify_conc;
    } elsif ( $acid_conc eq "0.160" || $acid_conc eq "0.16"
                                    || $acid_conc == 0.16 ) {
        $acid_conc = "0.160";
        undef $specify_conc;
    } elsif ( $acid_conc eq "0.01639" || $acid_conc == 0.1639 ) {
        $acid_conc = "0.01639";
        undef $specify_conc;
    } else {
        $specify_conc =~ s/[^+-.eE\d]//g;
        $acid_conc    = "other";
    }
    &acid_option_sub($acid_conc);
    $lotnumber        = $sd[$i]{'lotnumber'};
    $cor_factor       = $sd[$i]{'cor_factor'};
    $cor_factor       =~ s/[^+-.eE\d]//g;
    $expiration       = $sd[$i]{'expiration'};
    $stir_method      = $sd[$i]{'stir_method'};
    $units            = $sd[$i]{'units'};
    $data_order       = $sd[$i]{'data_order'};
    $data_order_label = $sd[$i]{'data_order_label'};

    $data_text->delete('1.0', 'end');
    $data_text->insert('end', $sd[$i]{'data'});
    $comments_text->delete('1.0', 'end');
    $comments_text->insert('end', $sd[$i]{'comments'});

    $inc_method       = $sd[$i]{'inc_method'};
    $gran_method      = $sd[$i]{'gran_method'};
    $fit_method       = $sd[$i]{'fit_method'};
    $fixed_method     = $sd[$i]{'fixed_method'};
    $carb_fixed       = $sd[$i]{'carb_fixed'};
    $bicarb_fixed     = $sd[$i]{'bicarb_fixed'};
    $carb_endpt2      = $sd[$i]{'carb_endpt2'};
    $carb_endpt2      =~ s/[^+-.eE\d]//g;
    $bicarb_endpt2    = $sd[$i]{'bicarb_endpt2'};
    $bicarb_endpt2    =~ s/[^+-.eE\d]//g;
}


sub print_win {
    my ($which) = @_;
    my ($psfile);

#   Get output file name.
    $psfile = $main->getSaveFile(
        -title => 'Save as PostScript',
        -defaultextension => ".ps",
        -filetypes => [ ['PostScript Files', '.ps'],
                        ['All Files', '*'],
                      ],
        );
    if (! defined $psfile) {
        return &pop_up_error("Output file not specified.\nAborting...");
    }

#   Get data from saved array (may have multiple output windows open).
    &get_data($which);

#   Open file for printing.
    open (PSF, ">$psfile") or return &pop_up_error("Unable to open\n$psfile");
    $psprint = 1;

#   Do the headers.
    &ps_header;
    &header();

#   Go to calcs.  No Tk stuff is made because "psprint" flag is on.
    $main->Busy(-recurse => 1);
    &calculate;
    $main->Unbusy;

#   Close file.  Clean up and return.
    &ps_footer;
    $psprint = 0;
    close (PSF) or return &pop_up_error("Trouble closing\n$psfile");

#   Raise the result window.
    $result_window[$which]->deiconify();
    $result_window[$which]->raise();
    $result_window[$which]->focus;
    return;
}


sub pop_up_info {
    my ($msg) = @_;
    $main->messageBox(
        -title   => "Notice",
        -icon    => 'info',
        -message => $msg,
        -type    => "OK",
        );
}


sub pop_up_error {
    my ($msg) = @_;
    $main->messageBox(
        -title   => "Error",
        -icon    => 'error',
        -message => $msg,
        -type    => "OK",
        );
}


sub pop_up_question {
    my ($question) = @_;
    $main->messageBox(
        -title   => "Question",
        -icon    => 'question',
        -message => $question,
        -type    => "YesNo",
        );
}


sub acid_option_sub {
    $acid_conc_label = $acid_conc = shift(@_);
    $acid_conc_label .= " N" unless ($acid_conc eq "other");
    
    if ($conc_entry && $conc_label && $conc_units) {
        if ($acid_conc eq "other") {
            $conc_entry->configure(-state      => 'normal',
                                   -foreground => $normal_color);
            $conc_entry->focus;
            $conc_label->configure(-foreground => $required_color);
            $conc_units->configure(-foreground => $normal_color);
        } else {
            $conc_entry->configure(-state      => 'disabled',
                                   -foreground => $disabled_color);
            $conc_label->configure(-foreground => $disabled_color);
            $conc_units->configure(-foreground => $disabled_color);
        }
    }
}


sub fixed_method_sub {
    if ($carb_ckbtn   && $carb_label   && $carb_entry &&
        $bicarb_ckbtn && $bicarb_label && $bicarb_entry) {
        if ($fixed_method) {
            $carb_ckbtn->configure(  -state      => 'normal',
                                     -foreground => $required_color);
            $bicarb_ckbtn->configure(-state      => 'normal',
                                     -foreground => $required_color);
            &set_carb_status;
            &set_bicarb_status;
        } else {
            $carb_ckbtn->configure(  -state      => 'disabled',
                                     -foreground => $disabled_color);
            $carb_label->configure(  -foreground => $disabled_color);
            $carb_entry->configure(  -state      => 'disabled',
                                     -foreground => $disabled_color);
            $bicarb_ckbtn->configure(-state      => 'disabled',
                                     -foreground => $disabled_color);
            $bicarb_label->configure(-foreground => $disabled_color);
            $bicarb_entry->configure(-state      => 'disabled',
                                     -foreground => $disabled_color);
        }
    }
}


sub set_carb_status {
    if ($carb_ckbtn && $carb_label && $carb_entry) {
        if ($carb_fixed) {
            $carb_label->configure(-foreground => $required_color);
            $carb_entry->configure(-state      => 'normal',
                                   -foreground => $normal_color);
        } else {
            $carb_label->configure(-foreground => $disabled_color);
            $carb_entry->configure(-state      => 'disabled',
                                   -foreground => $disabled_color);
        }
    }
}


sub set_bicarb_status {
    if ($bicarb_ckbtn && $bicarb_label && $bicarb_entry) {
        if ($bicarb_fixed) {
            $bicarb_label->configure(-foreground => $required_color);
            $bicarb_entry->configure(-state      => 'normal',
                                     -foreground => $normal_color);
        } else {
            $bicarb_label->configure(-foreground => $disabled_color);
            $bicarb_entry->configure(-state      => 'disabled',
                                     -foreground => $disabled_color);
        }
    }
}


sub set_cor_factor {
    if ($units eq "digital") {
        $cor_factor = "1.01";
    } else {
        $cor_factor = "1.00";
    }
}


sub change_font_family {
    my ($family) = @_;
    my ($name);

    if ($family ne $default_font_family) {
        foreach $name (qw/default bo it boit
                          big bigbo bigit bigboit
                          med medbo medit medboit
                          sm  smbo  smit  smboit/) {
            $main->fontConfigure($name, -family => $family);
        }
    }
    $default_font_family = $family;
}


sub change_font_size {
    my ($size) = @_;
    my ($name);

    if ($size ne $default_font_size) {
        foreach $name (qw/default bo it boit
                          cour courbo courit courboit/) {
            $main->fontConfigure($name, -size => $size);
        }
        foreach $name (qw/big bigbo bigit bigboit/) {
            $main->fontConfigure($name, -size => int(1.5*$size));
        }
        foreach $name (qw/med medbo medit medboit/) {
            $main->fontConfigure($name, -size => int(1.25*$size));
        }
        foreach $name (qw/sm smbo smit smboit/) {
            $main->fontConfigure($name, -size => int(0.65*$size));
        }
        if ( $have_symbol_font ) {
            foreach $name (qw/sym symbo symit symboit/) {
                $main->fontConfigure($name, -size => $size);
            }
        }
    }
    $default_font_size = $size;
}


sub reset_form {
    undef $site_name;
    undef $site_id;
    undef $collect_date;
    undef $collect_time;
    undef $temp_input;
    undef $spcond_input;
    undef $analyst;
    undef $analysis_date;
    undef $analysis_time;
    undef $volume;
    $filtered = "yes";
    undef $specify_conc;
    &acid_option_sub("0.160");
    undef $lotnumber;
    $cor_factor = "1.01";
    undef $expiration;
    $stir_method = "magnetic";
    $units = "digital";
    $data_order = "pH_first";
    $data_order_label = "pH in 1st column, titrant volume in 2nd";
    $data_text->delete('1.0', 'end');
    $comments_text->delete('1.0', 'end');
    $inc_method    = 1;
    $gran_method   = 0;
    $fit_method    = 0;
    $fixed_method  = 0;
    $carb_fixed    = 1;
    $bicarb_fixed  = 1;
    $carb_endpt2   = 8.3;
    $bicarb_endpt2 = 4.5;
    &fixed_method_sub;
}


sub open_result_window {
    my ($i, $result_pane);

    $i = $#resultlist;
#   if ( $i >= 0 && Exists($result_window[$i]) ) {
#       $result_window[$i]->destroy;
#   }
    push (@resultlist, $i);
    $i = $#resultlist;

#   Get the date and time
    $date_time = &get_datetime;

#   Save data in an array for use in printing results later
    &save_data($i);

#   Make the window
    $result_window[$i] = $main->Toplevel();
    $result_window[$i]->title("Results of Alkalinity Calculator");
    $result_window[$i]->minsize(350,300);
    $result_window[$i]->focus;
    $result_window[$i]->configure(-cursor => $cursor_shape);

#   Make a menu bar
    &make_menubar($result_window[$i], $i);

#   Make a header
    &header($result_window[$i]);

#   Make a footer
    &footer($result_window[$i]);

#   Scrolled pane to hold the form, with optional scrollbars
    $result_pane = $result_window[$i]->Scrolled('Pane',
        -width => $pane_width,
        -height => 0.65 * $screenheight,
        -scrollbars => 'osoe',
        )->pack(-side => 'left',
                -fill => 'both',
                -expand => 1,
                -anchor => 'nw');
    return $result_pane;
}


sub header {
    my ($window) = @_;
    my ($tw, $content);
    return if ($psprint);

    $tw = $window->ROText(
        -height     => 7,
        -relief     => 'flat',
        -font       => 'default',
        -background => $background_color,
        -cursor     => $cursor_shape,
        -wrap       => 'word',
        )->pack(-fill => 'x');
    $content = "
<img src=\"images/usgs.gif\" width=72 height=20>
<h1>Results of Alkalinity Calculator</h1>
<p><b>Date:</b> $date_time
<br><b>Version:</b> $version [<a href=\"version_history.html\">version
history</a>]";
    &parse($tw, $content);
}


sub footer {
    my ($window) = @_;
    my ($frame);

    $frame = $window->Frame(
        -relief => 'groove',
        -borderwidth => 2,
        )->pack(-side => 'bottom', -fill => 'x');
    $frame->Label(
        -textvariable => \$status{$window},
        -justify => 'left',
        -font => 'default',
        )->pack(-side => 'left');
    $frame->Label(
        -text => $version,
        -justify => 'right',
        -font => 'default',
        )->pack(-side => 'right');
}


sub open_frame {
    my ($parent, $row) = @_;
    my ($frame);
    return if ($psprint);

    $frame = $parent->Frame(
        )->grid(-row => $row, -column => 1, -sticky => 'nw');
    return $frame;
}


sub print_row {
    my ($frame, $row, $left, $right) = @_;

    if ($psprint) {
        &ps_newline;
        &ps_text($ps_col2, $ps_y, $left, 'ne',
                 "$ps_fontsize bold", 'black', 'right');
        &ps_text($ps_col2, $ps_y, $right, 'nw', $ps_fontsize);

    } else {
        $frame->Label(
            -text => $left,
            -font => 'bo',
            )->grid(-row => $row, -column => 0, -sticky => 'ne');
        $frame->Label(
            -text => $right,
            -font => 'default',
            -justify => 'left',
            )->grid(-row => $row, -column => 1, -sticky => 'nw');
    }
}


sub print_col1 {
    my ($frame, $row, $label) = @_;
    my ($i, $n, $y);

    if ($psprint) {
        &ps_newline;
        &ps_newline if ($label eq "Titration Data: ");
        $i = $n = 0;
        while (substr($label, $i) =~ /\n/) {
            $i = index($label, "\n", $i) + 1;
            $n++;
            last if ($i > length($label));
        }
        if ($ps_y - 1.33 * $ps_fontsize * ($n + 1) < $ps_margin) {
            &ps_newpage;
        }
        $y = $ps_y;
        &ps_text($ps_col2, $ps_y, $label, 'ne',
                 "$ps_fontsize bold", 'black', 'right');
        $ps_y = $y;

    } else {
        $frame->Label(
            -text => $label,
            -justify => 'right',
            -font => 'bo',
            )->grid(-row => $row, -column => 0, -sticky => 'ne');
    }
}


sub print_col2_warn {
    my ($frame, $row, $msg) = @_;

    if ($psprint) {
        &ps_text($ps_col2, $ps_y, $msg, 'nw', $ps_fontsize, $warn_color);

    } else {
        $frame->Label(
            -text => $msg,
            -font => 'default',
            -foreground => $warn_color,
            -justify => 'left',
            )->grid(-row => $row, -column => 1, -sticky => 'nw');
    }
}


sub print_error {
    my ($parent, $row, $col, $msg1, $msg2) = @_;
    my ($tw, $colspan, $sav_x);

    $colspan = 1;
    if ( $col < 0 ) {
        $colspan = abs($col);
        $col = 0;
    }
    if ($psprint) {
        &ps_newline;
        $ps_x  = $ps_col1;
        $ps_x  = $ps_col2 if ($col > 0);
        $sav_x = $ps_x;
        &ps_text($ps_x, $ps_y, $msg1, 'nw',
                 "$ps_fontsize bold", $warn_color);
        &ps_text($sav_x, $ps_y, $msg2, 'nw',
                 $ps_fontsize, $warn_color, 'left', $ps_x - $sav_x);

    } else {
        $tw = $parent->ROText(
            -height => 6,
            -width => 40,
            -relief => 'flat',
            -font => 'default',
            -foreground => $warn_color,
            -background => $background_color,
            -cursor => $cursor_shape,
            -wrap => 'word',
            )->grid(-row        => $row,
                    -column     => $col,
                    -columnspan => $colspan,
                    -sticky     => 'nsew');
        $tw->tagConfigure('bo', -font => 'bo');
        $tw->insert('end', $msg1, 'bo');
        $tw->insert('end', $msg2);
        $tw->configure(-state => 'disabled');
    }
}


sub print_table_hdr {
    my ($frame, @headings) = @_;
    my ($i, $x);

    if ($psprint) {
        $x = $ps_col2;
        for ($i=0; $i<=$#headings; $i++) {
            &ps_filled_rect($x, $ps_y, $x + $ps_twidth{data}[$i],
                            $ps_y - 1.33 * $ps_fontsize, $banner_color);
            &ps_rect($x, $ps_y, $x + $ps_twidth{data}[$i],
                            $ps_y - 1.33 * $ps_fontsize, $normal_color);
            $x += $ps_twidth{data}[$i] / 2.0;
            &ps_text($x, $ps_y, $headings[$i], 'n', "$ps_fontsize bold",
                     $normal_color, 'center', 0, $ps_twidth{data}[$i]);
            $x += $ps_twidth{data}[$i] / 2.0;
        }

    } else {
        for ($i=0; $i<=$#headings; $i++) {
            $frame->Label(
                -text => $headings[$i],
                -font => 'bo',
                -relief => 'groove',
                -background => $banner_color,
            )->grid(-row => 0, -column => $i, -sticky => 'ew', -ipadx => 3);
        }
    }
}


sub print_table_row {
    my ($frame, $row, @content) = @_;
    my ($i, $x);

    if ($psprint) {
        &ps_newline;
        $x = $ps_col2;
        for ($i=0; $i<=$#content; $i++) {
            &ps_rect($x, $ps_y, $x + $ps_twidth{data}[$i],
                     $ps_y - 1.33 * $ps_fontsize, $normal_color);
            $x += $ps_twidth{data}[$i] / 2.0;
            &ps_text($x, $ps_y, $content[$i], 'n', $ps_fontsize,
                     $normal_color, 'center', 0, $ps_twidth{data}[$i]);
            $x += $ps_twidth{data}[$i] / 2.0;
        }

    } else {
        for ($i=0; $i<=$#content; $i++) {
            $frame->Label(
                -text => $content[$i],
                -font => 'default',
                -relief => 'groove',
                -background => 'white',
            )->grid(-row => $row, -column => $i, -sticky => 'ew');
        }
    }
}


sub parse_table_row {
    my ($frame, $row, @content) = @_;
    my ($i, $specs, $x, $maxlen);

    if ($psprint) {
        &ps_newline;
        $x = $ps_col2;
        for ($i=0; $i<=$#content; $i++) {
            &ps_rect($x, $ps_y, $x + $ps_twidth{$ps_tname}[$i],
                     $ps_y - 1.66 * $ps_fontsize, $normal_color);
            $x += $ps_twidth{$ps_tname}[$i];
        }
        $ps_y -= 0.165 * $ps_fontsize;
        $x = $ps_col2;
        for ($i=0; $i<=$#content; $i++) {
            if ($content[$i] =~ /<center>/) {
                $maxlen = &ps_text_length($content[$i], $ps_fontsize,
                                          $ps_twidth{$ps_tname}[$i] - 6);
                $ps_x = $x + 3 + ($ps_twidth{$ps_tname}[$i] - 6 - $maxlen)/2;
            } else {
                $ps_x = $x + 3;
            }
            &parse(' ', $content[$i], $ps_twidth{$ps_tname}[$i] - 6);
            $x += $ps_twidth{$ps_tname}[$i];
        }
        $ps_y -= 0.165 * $ps_fontsize;

    } else {
        $specs = { row     => $row,
                   rowspan => 1,
                   colspan => 1,
                   lines   => 1,
                   relief  => 'groove',
                   bgcolor => 'white',
                 };
        for ($i=0; $i<=$#content; $i++) {
            $specs->{col} = $i;
            &parse_cell($frame, $specs, $content[$i]);
        }
    }
}


sub parse_table_row2 {
    my ($frame, $row, @content) = @_;
    my ($i, $specs, $x, $y);

    if ($psprint) {
        &ps_newline;
        $x = $ps_col2 + $ps_twidth{$ps_tname}[0];
        for ($i=0; $i<=$#content; $i++) {
            &ps_rect($x, $ps_y, $x + $ps_twidth{$ps_tname}[$i+1],
                     $ps_y - 1.66 * $ps_fontsize, $normal_color);
            $x += $ps_twidth{$ps_tname}[$i+1];
        }
        $ps_y -= 0.165 * $ps_fontsize;
        $x = $ps_col2 + $ps_twidth{$ps_tname}[0];
        for ($i=0; $i<=$#content; $i++) {
            $ps_x = $x + 3;
            &parse(' ', $content[$i], $ps_twidth{$ps_tname}[$i+1] - 6);
            $x += $ps_twidth{$ps_tname}[$i+1];
        }
        $ps_y -= 0.165 * $ps_fontsize;
        $y     = $ps_y - 1.33 * $ps_fontsize;
        if ($ps_rspan > 1) {
            &ps_line($ps_col2, $ps_droplines[1], $ps_col2, $y, $normal_color);
            $ps_droplines[1] = $y;
        } elsif ($ps_rspan == 1) {
            &ps_line($ps_col2, $ps_droplines[1], $ps_col2, $y,
                     $ps_col2 + $ps_twidth{$ps_tname}[0], $y, $normal_color);
            @ps_droplines = ();
        }
        $ps_rspan--;

    } else {
        $specs = { row     => $row,
                   rowspan => 1,
                   colspan => 1,
                   lines   => 1,
                   relief  => 'groove',
                   bgcolor => 'white',
                 };
        for ($i=0; $i<=$#content; $i++) {
            $specs->{col} = $i+1;
            &parse_cell($frame, $specs, $content[$i]);
        }
    }
}


sub parse_table_rspan {
    my ($frame, $row, $rowspan, $content) = @_;
    my ($specs, $y, $i);

    if ($psprint) {
        &ps_newline;
        $y            = $ps_y;
        @ps_droplines = ($ps_col2, $y);
        $ps_rspan     = $rowspan;
        &ps_line($ps_col2,                            $y,
                 $ps_col2 + $ps_twidth{$ps_tname}[0], $y, $normal_color);
        $ps_y -= 0.165 * $ps_fontsize;
        $ps_x  = $ps_col2 + 3;
        &parse(' ', $content, $ps_twidth{$ps_tname}[0] - 6);
        $ps_y  = $y + $ps_rowheight;

    } else {
        $specs = { row     => $row,
                   rowspan => $rowspan,
                   col     => 0,
                   colspan => 1,
                   lines   => 1,
                   relief  => 'groove',
                   bgcolor => 'white',
                 };
        &parse_cell($frame, $specs, $content);
    }
}


sub parse_col2 {
    my ($frame, $row, $content) = @_;
    my ($specs);

    if ($psprint) {
        $ps_x = $ps_col2;
        &parse(' ', $content, $ps_xpagesize - $ps_margin - $ps_col2);

    } else {
        $specs = { row     => $row,
                   col     => 1,
                   rowspan => 1,
                   colspan => 1,
                   lines   => 1,
                   relief  => 'flat',
                   bgcolor => $background_color,
                 };
        &parse_cell($frame, $specs, $content);
    }
}


sub parse_table_hdr {
    my ($frame, $row, @content) = @_;
    my ($i, $specs, $x, $maxlen);

    if ($psprint) {
        $x = $ps_col2;
        for ($i=0; $i<=$#content; $i++) {
            &ps_filled_rect($x, $ps_y, $x + $ps_twidth{$ps_tname}[$i],
                            $ps_y - 1.66 * $ps_fontsize, $banner_color);
            &ps_rect($x, $ps_y, $x + $ps_twidth{$ps_tname}[$i],
                            $ps_y - 1.66 * $ps_fontsize, $normal_color);
            $x += $ps_twidth{$ps_tname}[$i];
        }
        $x = $ps_col2;
        $ps_y -= 0.165 * $ps_fontsize;
        for ($i=0; $i<=$#content; $i++) {
            if ($content[$i] =~ /<center>/) {
                $maxlen = &ps_text_length($content[$i], $ps_fontsize,
                                          $ps_twidth{$ps_tname}[$i] - 6);
                $ps_x = $x + 3 + ($ps_twidth{$ps_tname}[$i] - 6 - $maxlen)/2;
            } else {
                $ps_x = $x + 3;
            }
            &parse(' ', $content[$i], $ps_twidth{$ps_tname}[$i] - 6);
            $x += $ps_twidth{$ps_tname}[$i];
        }
        $ps_y -= 0.165 * $ps_fontsize;

    } else {
        $specs = { row     => $row,
                   rowspan => 1,
                   colspan => 1,
                   lines   => 1,
                   relief  => 'groove',
                   bgcolor => $banner_color,
                 };
        for ($i=0; $i<=$#content; $i++) {
            $specs->{col} = $i;
            &parse_cell($frame, $specs, $content[$i]);
        }
    }
}


sub parse_cell {
    my ($frame, $specs, $content, $wrapwidth) = @_;
    my ($width, $height, $tw);

    return if ($psprint);

    $wrapwidth = 65 if ( ! $wrapwidth );

    $tw = $frame->ROText(
        -width      => 65,
        -font       => 'default',
        -cursor     => $cursor_shape,
        -wrap       => 'word',
        -relief     => $specs->{relief},
        -background => $specs->{bgcolor},
        )->grid(-row        => $specs->{row},
                -rowspan    => $specs->{rowspan},
                -column     => $specs->{col},
                -columnspan => $specs->{colspan},
                -sticky     => 'nsew');
    ($width, $height) = &parse($tw, $content, $wrapwidth);
    if ( $specs->{lines} ) {
        $height = $specs->{lines};
    }
    $tw->configure(-width => $width, -height => $height);
}


sub parse_msg_span {
    my ($frame, $row, $content, $colspan) = @_;
    my ($specs);

    if ($psprint) {
        &ps_newline;
        $ps_x  = $ps_col2;
        $ps_x  = $ps_col1 if ($colspan > 1);
        $ps_y -= 0.165 * $ps_fontsize;
        &parse(' ', $content, $ps_xpagesize - $ps_margin - $ps_x);
        $ps_y -= 0.165 * $ps_fontsize;

    } else {
        $specs = { row     => $row,
                   col     => 0,
                   rowspan => 1,
                   colspan => $colspan,
                   lines   => 0,
                   relief  => 'flat',
                   bgcolor => $background_color,
                 };
        &parse_cell($frame, $specs, $content);
    }
}


sub parse_table_span {
    my ($frame, $row, $content, $colspan) = @_;
    my ($specs, $i, $width, $y, $y2, $maxlen);

    if ($psprint) {
        &ps_newline;
        $width = 0;
        for ($i=0; $i<$colspan; $i++) {
            $width += $ps_twidth{$ps_tname}[$i];
        }
        $y = $ps_y;
        push(@ps_droplines, $ps_col2, $y, $ps_col2 + $width, $y);

        if ($content =~ /<center>/) {
            $maxlen = &ps_text_length($content, $ps_fontsize, $width - 6);
            $ps_x = $ps_col2 + 3 + ($width - 6 - $maxlen)/2;
        } else {
            $ps_x = $ps_col2 + 3;
        }
        $ps_y -= 0.165 * $ps_fontsize;
        &parse(' ', $content, $width - 6);
        $ps_y -= 0.165 * $ps_fontsize;

        $y2 = $ps_y - 1.33 * $ps_fontsize;
        if ($y > $y2) {
            &ps_rect($ps_col2,          $y,
                     $ps_col2 + $width, $y2, $normal_color);
        } else {
            $y = $ps_ypagesize - $ps_margin;
            &ps_line($ps_col2,          $y,  $ps_col2,          $y2,
                     $ps_col2 + $width, $y2, $ps_col2 + $width, $y,
                     $normal_color);
        }
        for ($i=0; $i<4; $i++) { pop(@ps_droplines) }

    } else {
        $specs = { row     => $row,
                   col     => 0,
                   rowspan => 1,
                   colspan => $colspan,
                   lines   => 0,
                   relief  => 'groove',
                   bgcolor => 'white',
                 };
        &parse_cell($frame, $specs, $content);
    }
}


sub parse_table_span2 {
    my ($frame, $row, $content, $colspan) = @_;
    my ($specs, $i, $width, $x, $y, $y2, $maxlen);

    if ($psprint) {
        &ps_newline;
        $width = 0;
        for ($i=1; $i<=$colspan; $i++) {
            $width += $ps_twidth{$ps_tname}[$i];
        }
        $y = $ps_y;
        $x = $ps_col2 + $ps_twidth{$ps_tname}[0];
        push(@ps_droplines, $x, $y, $x + $width, $y);

        if ($content =~ /<center>/) {
            $maxlen = &ps_text_length($content, $ps_fontsize, $width - 6);
            $ps_x = $x + 3 + ($width - 6 - $maxlen)/2;
        } else {
            $ps_x = $x + 3;
        }
        $ps_y -= 0.165 * $ps_fontsize;
        &parse(' ', $content, $width - 6);
        $ps_y -= 0.165 * $ps_fontsize;

        $y2 = $ps_y - 1.33 * $ps_fontsize;
        if ($y > $y2) {
            &ps_rect($x, $y, $x + $width, $y2, $normal_color);
            if ($ps_rspan > 1) {
                &ps_line($ps_col2, $ps_droplines[1],
                         $ps_col2, $y2, $normal_color);
                $ps_droplines[1] = $y2;
            } elsif ($ps_rspan == 1) {
                &ps_line($ps_col2, $ps_droplines[1], $ps_col2, $y2,
                         $ps_col2 + $ps_twidth{$ps_tname}[0], $y2,
                         $normal_color);
            }
        } else {
            $y = $ps_ypagesize - $ps_margin;
            &ps_line($x,          $y,  $x,          $y2,
                     $x + $width, $y2, $x + $width, $y, $normal_color);
            if ($ps_rspan > 1) {
                &ps_line($ps_col2, $y, $ps_col2, $y2, $normal_color);
                $ps_droplines[1] = $y2;
            } elsif ($ps_rspan == 1) {
                &ps_line($ps_col2, $y, $ps_col2, $y2,
                         $ps_col2 + $ps_twidth{$ps_tname}[0], $y2,
                         $normal_color);
            }
        }
        for ($i=0; $i<4; $i++) { pop(@ps_droplines) }
        if ($ps_rspan == 1) {
            @ps_droplines = ();
        }
        $ps_rspan--;

    } else {
        $specs = { row     => $row,
                   col     => 1,
                   rowspan => 1,
                   colspan => $colspan,
                   lines   => 0,
                   relief  => 'groove',
                   bgcolor => 'white',
                 };
        &parse_cell($frame, $specs, $content, 60);
    }
}


sub print_table_hdr_span {
    my ($frame, $row, $heading, $colspan) = @_;
    my ($i, $x, $width);

    if ($psprint) {
        $x = $ps_col2;
        $width = 0;
        for ($i=0; $i<$colspan; $i++) {
            $width += $ps_twidth{$ps_tname}[$i];
        }
        &ps_filled_rect($x, $ps_y, $x + $width,
                        $ps_y - 1.66 * $ps_fontsize, $banner_color);
        &ps_rect($x, $ps_y, $x + $width,
                        $ps_y - 1.66 * $ps_fontsize, $normal_color);
        $x += $width / 2.0;
        $ps_y -= 0.165 * $ps_fontsize;
        &ps_text($x, $ps_y, $heading, 'n',
                 "$ps_fontsize bold", $normal_color, 'center', 0, $width);
        $ps_y -= 0.165 * $ps_fontsize;

    } else {
        $frame->Label(
            -text => $heading,
            -width => 65,
            -font => 'bo',
            -relief => 'groove',
            -background => $banner_color,
        )->grid(-row => $row, -column => 0, -columnspan => $colspan,
                -sticky => 'ew', -ipadx => 3);
    }
}


sub initialize_graph {
    my ($parent, $row, $view, $title, $x, $y, $y2) = @_;
    my ($canvas, $shortside, $xmin, $xmax, $ymin, $ymax);
    my ($t, $pos, $i, $ticklen);
    my $axis_font  = "{Helvetica} 9 bold";
    my $tick_font  = "{Helvetica} 7 bold";
    my $title_font = "{Helvetica} 10 bold";

    if (! $psprint) {
        $canvas = $parent->Canvas(
            -background => 'white',
            -width => $view->{x}{pix},
            -height => $view->{y}{pix},
            )->grid(-row => $row, -column => 1, -sticky => 'nw');
    } else {
        $canvas = &ps_setup_graph($view->{x}{pix}, $view->{y}{pix});
    }

    $shortside = $view->{x}{pix};
    $shortside = $view->{y}{pix} if ($shortside > $view->{y}{pix});
    $xmin = $shortside * $view->{x}{min};
    $xmax = $shortside * $view->{x}{max};
    $ymin = $shortside * ($view->{y}{pix} / $shortside - $view->{y}{min});
    $ymax = $shortside * ($view->{y}{pix} / $shortside - $view->{y}{max});

    &make_rect($canvas, $xmin, $ymin, $xmax, $ymax);

    $ticklen = int(0.023 * ($xmax - $xmin + $ymin - $ymax) / 2);

#   X axis
    for ($t=$x->{min}; $t<=$x->{max}; $t+=$x->{major}) {
        $pos = $xmin + ($t - $x->{min}) *
                       ($xmax - $xmin) / ($x->{max} - $x->{min});
        &make_line($canvas, $pos, $ymax, $pos, $ymax + $ticklen);
        &make_line($canvas, $pos, $ymin, $pos, $ymin - $ticklen);
        &make_text($canvas, $pos, $ymin + $ticklen/2,
                   sprintf("%.$x->{prec}f", $t), 'n', $tick_font);

        if ( $t != $x->{max} && $x->{minorticks} != 0 ) {
            for ($i=1; $i<=$x->{minorticks}; $i++) {
                $pos = $xmin + ($t + $i * $x->{major} / (1 + $x->{minorticks})
                       - $x->{min}) *
                       ($xmax - $xmin) / ($x->{max} - $x->{min});
                &make_line($canvas, $pos, $ymin, $pos, $ymin - $ticklen/2);
                &make_line($canvas, $pos, $ymax, $pos, $ymax + $ticklen/2);
            }
        }
    }
    $pos = $xmin + ($xmax - $xmin)/2;
    &make_text($canvas, $pos, $ymin + 2.5 * $ticklen,
               $x->{label}, 'n', $axis_font);

#   Left Y axis
    for ($t=$y->{min}; $t<=$y->{max}; $t+=$y->{major}) {
        $pos = $ymin - ($t - $y->{min}) *
                       ($ymin - $ymax) / ($y->{max} - $y->{min});
        &make_line($canvas, $xmin, $pos, $xmin + $ticklen, $pos);
        if ( ! ref($y2) ) {
            &make_line($canvas, $xmax, $pos, $xmax - $ticklen, $pos);
        }
        if ( $y->{ticklabels} ) {
            &make_text($canvas, $xmin - $ticklen/2, $pos,
                sprintf("%.$y->{prec}f", $t), 'e', $tick_font, $y->{color});
        }

        if ( $t != $y->{max} && $y->{minorticks} != 0 ) {
            for ($i=1; $i<=$y->{minorticks}; $i++) {
                $pos = $ymin - ($t + $i * $y->{major} / (1 + $y->{minorticks})
                       - $y->{min}) *
                       ($ymin - $ymax) / ($y->{max} - $y->{min});
                &make_line($canvas, $xmin, $pos, $xmin + $ticklen/2, $pos);
                if ( ! ref($y2) ) {
                    &make_line($canvas, $xmax, $pos, $xmax - $ticklen/2, $pos);
                }
            }
        }
    }
    $pos = $ymax + ($ymin - $ymax)/2;
    $y->{label} =~ s/(.)/$1\n/g;
    chomp $y->{label};
    $y->{prec} = 0 if ( ! $y->{ticklabels} );
    &make_text($canvas, $xmin - (2.3 + 0.9 * $y->{prec}) * $ticklen, $pos,
               $y->{label}, 'e', $axis_font, $y->{color}, 'center');

#   Right Y axis
    if ( ref($y2) ) {
        for ($t=$y2->{min}; $t<=$y2->{max}; $t+=$y2->{major}) {
            $pos = $ymin - ($t - $y2->{min}) *
                           ($ymin - $ymax) / ($y2->{max} - $y2->{min});
            &make_line($canvas, $xmax, $pos, $xmax - $ticklen, $pos);
            &make_text($canvas, $xmax + $ticklen/2, $pos,
                sprintf("%.$y2->{prec}f", $t), 'w', $tick_font, $y2->{color});

            if ( $t != $y2->{max} && $y2->{minorticks} != 0 ) {
                for ($i=1; $i<=$y2->{minorticks}; $i++) {
                    $pos = $ymin - ($t + $i * $y2->{major}
                           / (1 + $y2->{minorticks}) - $y2->{min}) *
                           ($ymin - $ymax) / ($y2->{max} - $y2->{min});
                    &make_line($canvas, $xmax, $pos, $xmax - $ticklen/2, $pos);
                }
            }
        }
        $pos = $ymax + ($ymin - $ymax)/2;
        $y2->{label} =~ s/(.)/$1\n/g;
        chomp $y2->{label};
        &make_text($canvas, $xmax + (2.3 + 0.9 * $y2->{prec}) * $ticklen, $pos,
                   $y2->{label}, 'w', $axis_font, $y2->{color}, 'center');
    }

#   Title
    $pos = $xmin + ($xmax - $xmin)/2;
    &make_text($canvas, $pos, $ymax - $ticklen/2, $title, 's', $title_font);

    return $canvas;
}


sub make_rect {
    my ($c, $x1, $y1, $x2, $y2, $color, $filled) = @_;

    $color  = "black" if (! defined($color));
    $filled = 0       if (! defined($filled));

    if (! $psprint) {
        if ($filled) {
            $c->createRectangle($x1, $y1, $x2, $y2,
                                   -fill => $color, -outline => $color);
        } else {
            $c->createRectangle($x1, $y1, $x2, $y2, -outline => $color);
        }
    } else {
        if ($filled) {
            &ps_filled_rect($x1, $y1, $x2, $y2, $color);
        } else {
            &ps_rect($x1, $y1, $x2, $y2, $color);
        }
    }
}


sub make_circle {
    my ($c, $x, $y, $r, $color) = @_;

    $color = "black" if (! defined($color));
    if (! $psprint) {
        $c->createOval($x-$r, $y-$r, $x+$r, $y+$r, -outline => $color);
    } else {
        &ps_circle($x, $y, $r, $color);
    }
}


sub make_line {
    my ($c, @xy) = @_;
    my ($type, $color);

#   Line type is optional last argument.
    $type = pop @xy;
    if (&list_match(lc($type), @valid_linetypes) == -1) {
        push (@xy, $type);
        undef $type;
    }
    $type = "solid" if (! defined($type));

#   Line color is optional last or next-to-last argument.
    $color = pop @xy;
    if (&list_match(lc($color), @valid_colors) == -1) {
        push (@xy, $color);
        undef $color;
    }
    $color = "black" if (! defined($color));

    if (! $psprint) {
        if ($type eq "dashed") {
            $c->createLine(@xy, -dash => '.', -fill => $color);
        } else {
            $c->createLine(@xy, -fill => $color);
        }
    } else {
        &ps_line(@xy, $color, $type);
    }
}


sub make_polygon {
    my ($c, @xy) = @_;
    my ($color);

#   Line color is optional last argument.
    $color = pop @xy;
    if (&list_match(lc($color), @valid_colors) == -1) {
        push (@xy, $color);
        undef $color;
    }
    $color = "black" if (! defined($color));

    if (! $psprint) {
        $c->createPolygon(@xy, -fill => undef, -outline => $color);
    } else {
        &ps_polygon(@xy, $color);
    }
}


sub make_text {
    my ($c, $x, $y, $text,
        $anchor, $font, $color, $just, $indent, $width, $cont) = @_;

    return if (! defined($text) or $text eq "");

    $anchor = "sw"                 if (! defined($anchor));
    $font   = "{Helvetica} 9 bold" if (! defined($font));
    $color  = "black"              if (! defined($color));
    $just   = "left"               if (! defined($just));
    $indent = 0                    if (! defined($indent));
    $width  = 0                    if (! defined($width));
    $width  = 10000                if ($ps_ingraph);
    $cont   = 0                    if (! defined($cont));

    if (! $psprint) {
        $c->createText($x, $y, -text => $text, -anchor => $anchor,
                       -font => $font, -fill => $color, -justify => $just);
    } else {
        &ps_text($x, $y, $text,
                 $anchor, $font, $color, $just, $indent, $width, $cont);
    }
}


sub plot_data {
    my ($canvas, $view, $x, $y, $d) = @_;
    my ($shortside, $xmin, $xmax, $ymin, $ymax, $symsize, $xleg, $yleg);
    my ($i, $xp, $yp, @xy, $tw, $width);
    my $legend_font  = "{Helvetica} 7 bold";

    $shortside = $view->{x}{pix};
    $shortside = $view->{y}{pix} if ($shortside > $view->{y}{pix});
    $xmin = $shortside * $view->{x}{min};
    $xmax = $shortside * $view->{x}{max};
    $ymin = $shortside * ($view->{y}{pix} / $shortside - $view->{y}{min});
    $ymax = $shortside * ($view->{y}{pix} / $shortside - $view->{y}{max});

    $symsize = int(0.02 * ($xmax - $xmin + $ymin - $ymax) / 2);
    $xleg = $shortside * $d->{legend}{xcor};
    $yleg = $shortside * ($view->{y}{pix} / $shortside - $d->{legend}{ycor});

    @xy = ();
    for ($i=0; $i<=$#{$d->{data}}; $i+=2) {
        $xp = $xmin + ($d->{data}[$i] - $x->{min}) *
                      ($xmax - $xmin) / ($x->{max} - $x->{min});
        $yp = $ymin - ($d->{data}[$i+1] - $y->{min}) *
                      ($ymin - $ymax) / ($y->{max} - $y->{min});
        next if ($xp > $xmax + 1 or $xp < $xmin - 1 or
                 $yp > $ymin + 1 or $yp < $ymax - 1);
        push (@xy, $xp, $yp);
    }

    if ( $d->{symbol} eq "circle" ) {
        for ($i=0; $i<=$#xy; $i+=2) {
            $xp = $xy[$i];
            $yp = $xy[$i+1];
            &make_circle($canvas, $xp, $yp, $symsize/2, $d->{color});
        }
        if ( $d->{line} ne "none" ) {
            &make_circle($canvas, $xleg + $symsize/2, $yleg,
                                  $symsize/2, $d->{color});
        }
        &make_circle($canvas, $xleg + 3.5 * $symsize, $yleg,
                              $symsize/2, $d->{color});

    } elsif ( $d->{symbol} eq "square" ) {
        for ($i=0; $i<=$#xy; $i+=2) {
            $xp = $xy[$i];
            $yp = $xy[$i+1];
            &make_rect($canvas, $xp - $symsize/2, $yp - $symsize/2,
                                $xp + $symsize/2, $yp + $symsize/2,
                                $d->{color});
        }
        if ( $d->{line} ne "none" ) {
            &make_rect($canvas, $xleg,            $yleg - $symsize/2,
                                $xleg + $symsize, $yleg + $symsize/2,
                                $d->{color});
        }
        &make_rect($canvas, $xleg + 3 * $symsize, $yleg - $symsize/2,
                            $xleg + 4 * $symsize, $yleg + $symsize/2,
                            $d->{color});

    } elsif ( $d->{symbol} eq "diamond" ) {
        for ($i=0; $i<=$#xy; $i+=2) {
            $xp = $xy[$i];
            $yp = $xy[$i+1];
            &make_polygon($canvas, $xp,              $yp - $symsize/2,
                                   $xp - $symsize/2, $yp,
                                   $xp,              $yp + $symsize/2,
                                   $xp + $symsize/2, $yp,
                                   $d->{color});
        }
        if ( $d->{line} ne "none" ) {
            &make_polygon($canvas, $xleg,              $yleg,
                                   $xleg + $symsize/2, $yleg + $symsize/2,
                                   $xleg + $symsize,   $yleg,
                                   $xleg + $symsize/2, $yleg - $symsize/2,
                                   $d->{color});
        }
        &make_polygon($canvas, $xleg + 3   * $symsize, $yleg,
                               $xleg + 3.5 * $symsize, $yleg + $symsize/2,
                               $xleg + 4   * $symsize, $yleg,
                               $xleg + 3.5 * $symsize, $yleg - $symsize/2,
                               $d->{color});

    } elsif ( $d->{symbol} eq "triangle" ) {
        for ($i=0; $i<=$#xy; $i+=2) {
            $xp = $xy[$i];
            $yp = $xy[$i+1];
            &make_polygon($canvas, $xp - $symsize/2, $yp + 0.289 * $symsize,
                                   $xp + $symsize/2, $yp + 0.289 * $symsize,
                                   $xp, $yp - $symsize/2,
                                   $d->{color});
        }
        if ( $d->{line} ne "none" ) {
            &make_polygon($canvas, $xleg,              $yleg + 0.289 * $symsize,
                                   $xleg + $symsize,   $yleg + 0.289 * $symsize,
                                   $xleg + $symsize/2, $yleg - $symsize/2,
                                   $d->{color});
        }
        &make_polygon($canvas, $xleg + 3 * $symsize,   $yleg + 0.289 * $symsize,
                               $xleg + 4 * $symsize,   $yleg + 0.289 * $symsize,
                               $xleg + 3.5 * $symsize, $yleg - $symsize/2,
                               $d->{color});

    } elsif ( $d->{symbol} eq "triangle-down" ) {
        for ($i=0; $i<=$#xy; $i+=2) {
            $xp = $xy[$i];
            $yp = $xy[$i+1];
            &make_polygon($canvas, $xp - $symsize/2, $yp - 0.289 * $symsize,
                                   $xp + $symsize/2, $yp - 0.289 * $symsize,
                                   $xp, $yp + $symsize/2,
                                   $d->{color});
        }
        if ( $d->{line} ne "none" ) {
            &make_polygon($canvas, $xleg,              $yleg - 0.289 * $symsize,
                                   $xleg + $symsize,   $yleg - 0.289 * $symsize,
                                   $xleg + $symsize/2, $yleg + $symsize/2,
                                   $d->{color});
        }
        &make_polygon($canvas, $xleg + 3 * $symsize,   $yleg - 0.289 * $symsize,
                               $xleg + 4 * $symsize,   $yleg - 0.289 * $symsize,
                               $xleg + 3.5 * $symsize, $yleg + $symsize/2,
                               $d->{color});

    } elsif ( $d->{symbol} eq "triangle-left" ) {
        for ($i=0; $i<=$#xy; $i+=2) {
            $xp = $xy[$i];
            $yp = $xy[$i+1];
            &make_polygon($canvas, $xp - $symsize/2,       $yp,
                                   $xp + 0.289 * $symsize, $yp + $symsize/2,
                                   $xp + 0.289 * $symsize, $yp - $symsize/2,
                                   $d->{color});
        }
        if ( $d->{line} ne "none" ) {
            &make_polygon($canvas, $xleg,                    $yleg,
                                   $xleg + 0.789 * $symsize, $yleg + $symsize/2,
                                   $xleg + 0.789 * $symsize, $yleg - $symsize/2,
                                   $d->{color});
        }
        &make_polygon($canvas, $xleg + 3     * $symsize, $yleg,
                               $xleg + 3.789 * $symsize, $yleg + $symsize/2,
                               $xleg + 3.789 * $symsize, $yleg - $symsize/2,
                               $d->{color});
    }

    if (&list_match(lc($d->{line}), @valid_linetypes) > -1) {
        &make_line($canvas, @xy, $d->{color}, $d->{line});
        &make_line($canvas, $xleg + 0.5 * $symsize, $yleg,
                            $xleg + 3.5 * $symsize, $yleg,
                            $d->{color}, $d->{line});
    }

    if ($psprint) {
        $ps_x = $xleg + 5 * $symsize;
        $ps_y = $yleg;
        &parse(' ', $d->{legend}{label}, 1000, $d->{color});
    } else {
        $tw = $canvas->ROText(
            -height     => 1,
            -relief     => 'flat',
            -font       => $legend_font,
            -foreground => $d->{color},
            -background => 'white',
            -cursor     => $cursor_shape,
            -wrap       => 'none',
            -highlightthickness => 0,
            );
        ($width, undef) = &parse($tw, $d->{legend}{label}, 100, 1);
        $tw->configure(-width => $width);
        $canvas->createWindow($xleg + 5 * $symsize, $yleg,
                              -window => $tw, -anchor => 'w');
    }
}


sub parse {
    my ($t, $content, $wrapwidth, $legend) = @_;

    $wrapwidth = 65 if ( ! defined ($wrapwidth) );

    my ($i, $j, $k, $n, $nf, $nl,
        @frag, @frag2, $pos, @tags, $font_tag,
        $bold, $italic, $sub, $sup, $symbol, $preformat, $comment,
        @sizecode, $size,
        $link, $link_tag, $link_ref, $mark,
        $tw, @current_tags, $match, $spanred,
        $image, $file, $center, $hcenter, $pcenter,
        $pindent, $pref, $indent, $indent2, $maxindent, $maxindent2,
        $intable, @tframe, $ntf, $in_table_cell, $tcell, $trow, $tcol, $tbold,
        @widest_cell, %gridinfo, $cs, $sum,
        @startrow, $safe_to_split, $single_cell,
        @rspan, @cspan, $rowspan, $colspan,
        %ops, $tjustify, $justify, $borderwidth, $padx, $pady, $ipadx, $ipady,
        $bgcolor, $tbl_bgcolor, $row_bgcolor, $relief,
        $cell_char, @line_breaks, $width, $max_width, $max_height,
        $nchar, $nlines, $longline,
        $ps_color, $ps_font, $sav_x, $ps_count, $fontsize,
        $listlevel, $bulletshape,
       );

    @sizecode = qw/sm reg med big/;
    $size = $borderwidth = 1;
    $bold = $italic = $sub = $sup = $symbol = $preformat = $comment = 0;
    $link = $nl = 0;
    $center = $hcenter = $pcenter = $spanred = 0;
    $pindent = $pref = $indent = $indent2 = $listlevel = 0;
    $maxindent = 3;
    $maxindent2 = 1;
    $bulletshape = "-";
    $intable = $in_table_cell = $trow = $tcol = $ntf = $tbold = 0;
    $padx = $pady = $ipadx = $ipady = 0;
    $justify = $tjustify = 'left';
    $nchar = $cell_char = $longline = 0;
    $nlines = 1;
    $sav_x = $ps_x;
    $ps_count = 0;

    if (! $psprint) {
        if ( $legend ) {
            &configure_legend_tags($t);
        } else {
            &configure_tags($t);
        }
    }

    $content =~ s/^\s+//;
    $content =~ s/\s+$//;

    @frag = split (/</, $content);
    for ($i=1; $i<=$#frag; $i++) {
        $frag[$i] = "<" . $frag[$i];
    }

    for ($i=0; $i<=$#frag; $i++) {
        if ( $preformat && $frag[$i] =~ /^<\/pre>/ ) {
            $preformat = 0;
        } elsif ( ! $preformat && $frag[$i] =~ /^<pre>/ ) {
            $preformat = 1;
            substr($frag[$i], index($frag[$i], ">") + 1, 0) = "\n";
        }

        if ( ! $preformat ) {
            if ( $comment ) {
                next if ( $frag[$i] !~ /-->/ );
                substr($frag[$i], 0, index($frag[$i], "-->") + 3) = "";
                $comment = 0;
            }

            $frag[$i] =~ s/\s+/ /g;
            $frag[$i] =~ s/<hr>//g;
            $frag[$i] =~ s/<\/?dl>//g;
            $frag[$i] =~ s/<p class="?top"?>//g;

            if ( $frag[$i] =~ /\&micro\;/ ) {
                if ( $Tk::VERSION >= 803. && ! $psprint ) {
                  # Newer versions of Tk expect the programmer to specify
                  #  the Unicode characters for greek glyphs.
                  # The micron char is \x{00B5}.
                    $frag[$i] =~ s/\&micro\;/\x{00B5}/g;
                } elsif ( $have_symbol_font ) {
                    $frag[$i] =~ s/\&micro\;/<font face=symbol>m<\/font>/g;
                    @frag2 = split (/</, $frag[$i]);
                    for ($j=1; $j<=$#frag2; $j++) {
                        $frag2[$j] = "<" . $frag2[$j];
                    }
                    splice(@frag, $i, 1, @frag2);
                } else {
                    $frag[$i] =~ s/\&micro\;/u/g;
                }
            }

            $frag[$i] =~ s/\&uuml\;/u/g;
            $frag[$i] =~ s/\&quot\;/\"/g;
            $frag[$i] =~ s/\&amp\;/\&/g;
            $frag[$i] =~ s/\&gt\;/\>/g;
            $frag[$i] =~ s/\&lt\;/\</g;
            $frag[$i] =~ s/<br>/\n/g;
            $frag[$i] =~ s/<p>/\n\n/g;
            $frag[$i] =~ s/\&nbsp\;/ /g;

            if ( $frag[$i] =~ /^<b>/ ) {
                $bold = 1;

            } elsif ( $frag[$i] =~ /^<\/b>/ ) {
                $bold = 0;

            } elsif ( $frag[$i] =~ /^<strong>/ ) {
                $bold = 1;

            } elsif ( $frag[$i] =~ /^<\/strong>/ ) {
                $bold = 0;

            } elsif ( $frag[$i] =~ /^<i>/ ) {
                $italic = 1;

            } elsif ( $frag[$i] =~ /^<\/i>/ ) {
                $italic = 0;

            } elsif ( $frag[$i] =~ /^<em>/ ) {
                $italic = 1;

            } elsif ( $frag[$i] =~ /^<\/em>/ ) {
                $italic = 0;

            } elsif ( $frag[$i] =~ /^<var>/ ) {
                $italic = 1;

            } elsif ( $frag[$i] =~ /^<\/var>/ ) {
                $italic = 0;

            } elsif ( $frag[$i] =~ /^<sub>/ ) {
                $sub = 1;
                $sup = 0;
                $size--;

            } elsif ( $frag[$i] =~ /^<\/sub>/ ) {
                $sub = 0;
                $size++;

            } elsif ( $frag[$i] =~ /^<sup>/ ) {
                $sup = 1;
                $sub = 0;
                $size--;

            } elsif ( $frag[$i] =~ /^<\/sup>/ ) {
                $sup = 0;
                $size++;

            } elsif ( $frag[$i] =~ /^<font face=symbol>/ ) {
                $symbol = 1;

            } elsif ( $frag[$i] =~ /^<\/font>/ ) {
                $symbol = 0;

            } elsif ( $frag[$i] =~ /^<a href="/ ) {
                $frag[$i] = substr($frag[$i], 9);
                $pos = index($frag[$i], "\"");
                if ( $pos > -1 ) {
                    $link_ref = substr($frag[$i], 0, $pos);
                    if ( $link_ref =~ /^\// ) {
                        if ( $link_ref eq "/alk" ||
                             $link_ref eq "/alk/alk.html" ) {
                            $link_ref = "Alkalinity Calculator";
                        } else {
                            substr($link_ref, 0, 0) = "http://or.water.usgs.gov";
                        }
                    }
                    if ($psprint) {
                        $link = 1;
                    } elsif ( $link_ref !~ /^mailto/ ) {
                        $link = 1;
                        $link_tag = "link$nl";
                        $nl++;
                        if (! $intable) {
                            $tw = $t;
                        } elsif ( $in_table_cell ) {
                            $tw = $tcell;
                        }
                        $tw->tagConfigure($link_tag, -underline => 1,
                                            -foreground => $link_color,
                                            -data => $link_ref);
                        $tw->tagBind($link_tag, "<Any-Enter>",
                            sub { $tw = shift;
                                  $tw->configure(-cursor => 'hand2');
                                  @current_tags = $tw->tagNames('current');
                                  $match = &list_search('link*', @current_tags);
                                  return if ($match < 0);
                                  $status{$tw->toplevel} = $tw->tagCget(
                                            $current_tags[$match], -data);
                                  });
                        $tw->tagBind($link_tag, "<Any-Leave>",
                            sub { $tw = shift;
                                  $tw->configure(-cursor => $cursor_shape);
                                  $status{$tw->toplevel} = "";
                                  });
                        $tw->tagBind($link_tag, "<Button-1>",
                            sub { $tw = shift;
                                  @current_tags = $tw->tagNames('current');
                                  $match = &list_search('link*', @current_tags);
                                  return if ($match < 0);
                                  &follow_link($tw->tagCget(
                                            $current_tags[$match], -data), $tw);
                                  });
                    }
                }

            } elsif ( $frag[$i] =~ /^<a name="/ ) {
                $frag[$i] = substr($frag[$i], 9);
                $pos = index($frag[$i], "\"");
                if ( $pos > -1 && ! $psprint ) {
                    $mark = substr($frag[$i], 0, $pos);
                    if (! $intable) {
                        $t->markSet($mark, 'current');
                        $t->markGravity($mark, 'left');
                    } elsif ( $in_table_cell ) {
                        $tcell->markSet($mark, 'current');
                        $tcell->markGravity($mark, 'left');
                    }
                }

            } elsif ( $frag[$i] =~ /^<\/a>/ ) {
                $link = 0;

            } elsif ( $frag[$i] =~ /^<img / ) {
                $frag[$i] = substr($frag[$i], 5);
                $pos = index($frag[$i], "src=\"");
                if ( $pos > -1 && ! $psprint ) {
                    $frag[$i] = substr($frag[$i], $pos + 5);
                    $pos = index($frag[$i], "\"");
                    if ( $pos > -1 ) {
                        $file  = substr($frag[$i], 0, $pos);
                        $image = $t->Label(-image => $t->Photo(-file => $file));
                        if (! $intable) {
                            $t->windowCreate('end', -window => $image);
                            if ( $center || $pcenter || $hcenter ) {
                                $t->tagAdd('center', "end - 2 chars");
                            }
                            if ( $indent ) {
                                $t->tagAdd("indent$indent$indent2", "end - 2 chars");
                            }
                        } elsif ( $in_table_cell ) {
                            $tcell->windowCreate('end', -window => $image);
                        }
                        # add to nlines if image is taller than text
                        %ops = &get_ops($frag[$i]);
                        $j = int( $ops{'height'} / $pts_per_pixel
                                        / $default_font_size -0.6);
                        $nlines += $j if ( $j > 0 );
                    }
                }

            } elsif ( $frag[$i] =~ /^<center>/ ) {
                $center = 1;

            } elsif ( $frag[$i] =~ /^<\/center>/ ) {
                $center = 0;
                if (substr($frag[$i], index($frag[$i], ">") + 1) eq " ") {
                    substr($frag[$i], index($frag[$i], ">") + 1) = "";
                }

            } elsif ( $frag[$i] =~ /^<h[1-9]>/ ) {
                $size   += 2 if ( $frag[$i] =~ /^<h[12]>/ );
                $size   += 1 if ( $frag[$i] =~ /^<h[34]>/ );
                $bold    = 1 if ( $frag[$i] =~ /^<h[1235]>/ );
                $italic  = 1 if ( $frag[$i] =~ /^<h6>/ );
                $hcenter = 1 if ( $frag[$i] =~ /^<h[12]>/ );
                substr($frag[$i], index($frag[$i], ">") +1, 0) = "\n";
                substr($frag[$i], index($frag[$i], ">") +1, 0) = "\n" if ($i>2);

            } elsif ( $frag[$i] =~ /^<\/h[1-9]>/ ) {
                $size   -= 2 if ( $frag[$i] =~ /^<\/h[12]>/ );
                $size   -= 1 if ( $frag[$i] =~ /^<\/h[34]>/ );
                $bold    = 0 if ( $frag[$i] =~ /^<\/h[1235]>/ );
                $italic  = 0 if ( $frag[$i] =~ /^<\/h6>/ );
                $hcenter = 0 if ( $frag[$i] =~ /^<\/h[12]>/ );

            } elsif ( $frag[$i] =~ /^<p class="?indent"?>/ ) {
                $pindent = 1;
                $indent++ if ($indent < $maxindent);
                substr($frag[$i], index($frag[$i], ">") + 1, 0) = "\n\n";

            } elsif ( $frag[$i] =~ /^<p class="?center"?>/ ) {
                $pcenter = 1;
                substr($frag[$i], index($frag[$i], ">") + 1, 0) = "\n\n";

            } elsif ( $frag[$i] =~ /^<p class="?reference"?>/ ) {
                $pref = 1;
                $indent++  if ($indent  < $maxindent);
                $indent2++ if ($indent2 < $maxindent2);
                substr($frag[$i], index($frag[$i], ">") + 1, 0) = "\n\n";

            } elsif ( $frag[$i] =~ /^<\/p>/ ) {
                $indent--  if (($pindent || $pref) && $indent > 0);
                $indent2-- if ($pref && $indent2 > 0);
                $pindent = $pcenter = $pref = 0;
                if (substr($frag[$i], index($frag[$i], ">") + 1) eq " ") {
                    substr($frag[$i], index($frag[$i], ">") + 1) = "";
                }

            } elsif ( $frag[$i] =~ /^<span class="?red"?>/ ) {
                $spanred = 1;

            } elsif ( $frag[$i] =~ /^<\/span>/ ) {
                $spanred = 0;

            } elsif ( $frag[$i] =~ /^<dt>/ ) {
                substr($frag[$i], index($frag[$i], ">") + 1, 0) = "\n\n";

            } elsif ( $frag[$i] =~ /^<\/dt>/ ) {
                if (substr($frag[$i], index($frag[$i], ">") + 1) eq " ") {
                    substr($frag[$i], index($frag[$i], ">") + 1) = "";
                }

            } elsif ( $frag[$i] =~ /^<dd>/ ) {
                $indent++ if ($indent < $maxindent);
                substr($frag[$i], index($frag[$i], ">") + 1, 0) = "\n";

            } elsif ( $frag[$i] =~ /^<\/dd>/ ) {
                $indent-- if ($indent > 0);
                if (substr($frag[$i], index($frag[$i], ">") + 1) eq " ") {
                    substr($frag[$i], index($frag[$i], ">") + 1) = "";
                }

            } elsif ( $frag[$i] =~ /^<ul>/ ) {
                $indent++ if ($indent < $maxindent);
                $listlevel++;
                if ( $Tk::VERSION >= 803. && ! $psprint ) {
                    if ( $listlevel % 2 == 0 ) {
                        $bulletshape = "\x{25E6}";  # small white bullet
                    } else {
                        $bulletshape = "\x{2022}";  # small black bullet
                    }
                } else {
                    if ( $listlevel % 2 == 0 ) {
                        $bulletshape = "+";
                    } else {
                        $bulletshape = "-";
                    }
                }
                if ( $listlevel == 1 ) {
                    substr($frag[$i], index($frag[$i], ">") + 1, 0) = "\n";
                }

            } elsif ( $frag[$i] =~ /^<li>/ ) {
                $indent2++ if ($indent2 < $maxindent2);
                substr($frag[$i], index($frag[$i], ">") + 1, 0)
                    = "\n$bulletshape ";

            } elsif ( $frag[$i] =~ /^<\/li>/ ) {
                $indent2-- if ($indent2 > 0);
                if (substr($frag[$i], index($frag[$i], ">") + 1) eq " ") {
                    substr($frag[$i], index($frag[$i], ">") + 1) = "";
                }

            } elsif ( $frag[$i] =~ /^<\/ul>/ ) {
                $indent-- if ($indent > 0);
                $listlevel-- if ($listlevel > 0);
                if ( $Tk::VERSION >= 803. && ! $psprint ) {
                    if ( $listlevel % 2 == 0 ) {
                        $bulletshape = "\x{25E6}";  # small white bullet
                    } else {
                        $bulletshape = "\x{2022}";  # small black bullet
                    }
                } else {
                    if ( $listlevel % 2 == 0 ) {
                        $bulletshape = "+";
                    } else {
                        $bulletshape = "-";
                    }
                }
                if (substr($frag[$i], index($frag[$i], ">") + 1) eq " ") {
                    substr($frag[$i], index($frag[$i], ">") + 1) = "";
                }

            } elsif ( $frag[$i] =~ /^<!--/ ) {
                $comment = 1;
                next if ( $frag[$i] !~ /-->/ );
                substr($frag[$i], 0, index($frag[$i], "-->") + 3) = "";
                $comment = 0;

            } elsif ( $frag[$i] =~ /^<table/ ) {
                $intable = 1;
                $trow = $tcol = $ntf = -1;
                @rspan = @cspan = ();
                @startrow = ();
                @widest_cell = ();

                %ops   = &get_ops($frag[$i]);
                $padx  = $pady = 0;
                $padx  = $pady = $ops{'cellspacing'} if ( $ops{'cellspacing'} );
                $ipadx = $ipady = 0;
                $ipadx = $ipady = $ops{'cellpadding'} if ( $ops{'cellpadding'});
                $borderwidth = 1;
                $borderwidth = $ops{'border'} if ( defined($ops{'border'}) );
                $tjustify    = 'left';
                $tjustify    = $ops{'align'} if ( $ops{'align'} );
                if ( $borderwidth == 0 ) {
                    $relief = 'flat';
                } else {
                    $borderwidth++;
                    $relief = 'raised';
                }
                $tbl_bgcolor = $background_color;
                $tbl_bgcolor = $ops{'bgcolor'} if ( $ops{'bgcolor'} );
                if (! $psprint) {
                    $t->insert('end', "\n");
                } else {
                    &ps_newline;
                }

                $longline = $nchar if ( $nchar > $longline );
                $nlines += 1 + int($nchar/$wrapwidth);
                $nchar = 0;

            } elsif ( $frag[$i] =~ /^<tr/ ) {
                $trow++;
                $tcol = -1;
                %ops = &get_ops($frag[$i]);
                $row_bgcolor = $tbl_bgcolor;
                $row_bgcolor = $ops{'bgcolor'} if ( $ops{'bgcolor'} );

#               Scrolled text widgets don't scroll well over large embedded
#               widgets.  Therefore, split each row of the table into a
#               separate frame, as long as not prohibited by a rowspan.
#               Don't split if each column can't be separately configured.

                if ( $trow > 0 ) {
                    $safe_to_split = 1;
                    $safe_to_split = 0 if ( $#{$rspan[$trow]} >= 0 );
                    for ($j=0; $j<=$#{$cspan[$startrow[$ntf]]}; $j++) {
                        $single_cell = 0;
                        for ($k=$startrow[$ntf]; $k<$trow; $k++) {
                            $single_cell = 1 if ( $cspan[$k][$j] == 0 );
                        }
                        $safe_to_split = 0 if ( ! $single_cell );
                    }
                }
                if ( ($trow == 0 || $safe_to_split) && ! $psprint ) {
                    $ntf++;
                    $startrow[$ntf] = $trow;
                    $t->insert('end', "\n");
                    $tframe[$ntf] = $t->Frame();
                    $t->windowCreate('end', -window => $tframe[$ntf]);
                    if ( $tjustify ne 'left' ) {
                        $t->tagAdd($tjustify, "end - 2 chars");
                    } elsif ( $center || $pcenter || $hcenter ) {
                        $t->tagAdd('center', "end - 2 chars");
                    }
                    if ( $indent ) {
                        $t->tagAdd("indent$indent$indent2", "end - 2 chars");
                    }
                }

            } elsif ( $frag[$i] =~ /^<t[hd]/ ) {
                if ( $frag[$i] =~ /^<th/ ) {
                    $tbold = 1;
                    $justify = 'center';
                } else {
                    $tbold = 0;
                    $justify = 'left';
                }

                $trow++ if ( $trow < 0 );
                $tcol++;
                $tcol++ until ( ! $rspan[$trow][$tcol]
                             && ! $cspan[$trow][$tcol] );
                %ops = &get_ops($frag[$i]);

                $justify = $ops{'align'} if ( $ops{'align'} );
                $bgcolor = $row_bgcolor;
                $bgcolor = $ops{'bgcolor'} if ( $ops{'bgcolor'} );

#               rspan is undef if not spanned from another row
#               cspan is either 0 or 1 to indicate membership in a colspan

                $rowspan = $colspan = 1;
                $colspan = $ops{'colspan'} if ( $ops{'colspan'} );
                $rowspan = $ops{'rowspan'} if ( $ops{'rowspan'} );
                for ($k=$tcol; $k<$tcol+$colspan; $k++) {
                    $cspan[$trow][$k] = 0;
                    $cspan[$trow][$k] = 1 if ( $colspan > 1 );
                    $widest_cell[$k]  = 0 if ($trow == 0);
                    for ($j=$trow+1; $j<$trow+$rowspan; $j++) {
                        $rspan[$j][$k] = 1;
                        $cspan[$j][$k] = 0;
                        $cspan[$j][$k] = 1 if ( $colspan > 1 );
                    }
                }

                if (! $psprint) {
                    $tcell = $tframe[$ntf]->ROText(
                        -width       => 20,
                        -height      => $rowspan,
                        -font        => 'default',
                        -cursor      => $cursor_shape,
                        -wrap        => 'none',
                        -relief      => $relief,
                        -background  => $bgcolor,
                        -borderwidth => $borderwidth,
                        )->grid(-row        => $trow - $startrow[$ntf],
                                -rowspan    => $rowspan,
                                -column     => $tcol,
                                -columnspan => $colspan,
                                -sticky     => 'nsew',
                                -padx       => $padx,
                                -pady       => $pady,
                                -ipadx      => $ipadx,
                                -ipady      => $ipady,
                                );
                    &configure_tags($tcell);
                }
                $in_table_cell = 1;
                $cell_char = 0;
                @line_breaks = ();

            } elsif ( $frag[$i] =~ /^<\/t[hd]>/ ) {
                $tbold = 0;
                $in_table_cell = 0;
                if ( $#line_breaks < 0 ) {
                    $max_width  = $cell_char;
                    $max_height = $rowspan;
                } else {
                    $max_width = $line_breaks[0];
                    for ($j=1; $j<=$#line_breaks; $j++) {
                        $width = $line_breaks[$j] - $line_breaks[$j-1];
                        $max_width = $width if ( $width > $max_width );
                    }
                    $max_height = $#line_breaks + 2;
                }
                if (! $psprint) {
                    $tcell->configure(-width  => $max_width,
                                      -height => $max_height,
                                      -state  => 'disabled');
                }
                if ( $max_width > $widest_cell[$tcol]
                     && ! $cspan[$trow][$tcol]) {
                    $widest_cell[$tcol] = $max_width;
                }

            } elsif ( $frag[$i] =~ /^<\/tr>/ ) {

            } elsif ( $frag[$i] =~ /^<\/table>/ ) {
                $intable = 0;
                if (substr($frag[$i], index($frag[$i], ">") + 1) eq " ") {
                    substr($frag[$i], index($frag[$i], ">") + 1) = "";
                }

#               If tables have been split into different frames,
#               figure out if any cell that spans columns is wider than
#               the sum of the widest columns they span.  If so, adjust
#               the individual column widths so that they are wider than
#               the spanning column.

                if (! $psprint) {
                    $startrow[$ntf+1] = -1;
                    if ( $ntf > 0 ) {
                        $nf = -1;
                        for ($j=0; $j<=$trow; $j++) {
                            $nf++ if ( $j == $startrow[$nf+1] );
                            for ($k=0; $k<=$#{$cspan[0]}; $k++) {
                                if ( $cspan[$j][$k] == 1
                                     && ( $k == 0 ||
                                        ( $k > 0 && $cspan[$j][$k-1] == 0 ) )) {
                                    ($tcell) = $tframe[$nf]->gridSlaves(
                                               -row => $j - $startrow[$nf],
                                               -column => $k);
                                    $width    = $tcell->cget("-width");
                                    %gridinfo = $tcell->gridInfo();
                                    $cs = $gridinfo{'-columnspan'};
                                    for ($n=0; $n<$cs; $n++) {
                                        $sum += $widest_cell[$k + $n];
                                    }
                                    if ( $sum < $width ) {
                                        for ($n=0; $n<$cs; $n++) {
                                            $widest_cell[$k + $n]
                                              += int(($width - $sum) / $cs) + 1;
                                        }
                                    }
                                }
                            }
                        }

#                       Force columns in different frames to have same widths.

                        $nf = -1;
                        for ($j=0; $j<=$trow; $j++) {
                            $nf++ if ( $j == $startrow[$nf+1] );
                            for ($k=0; $k<=$#{$cspan[0]}; $k++) {
                                if ( $cspan[$j][$k] == 0 ) {
                                    ($tcell) = $tframe[$nf]->gridSlaves(
                                               -row => $j - $startrow[$nf],
                                               -column => $k);
                                    $tcell->configure(
                                               -width => $widest_cell[$k]);
                                }
                            }
                        }
                    }
                    $nlines += int($trow * (2.0 + ($pady + $ipady)
                                         /$pts_per_pixel/$default_font_size));
                    $j = 0;
                    for ($k=0; $k<=$#{$cspan[0]}; $k++) {
                        $j += $widest_cell[$k];
                    }
                    $longline = $j if ( $j > $longline );
                }
            }

        }
        substr($frag[$i], 0, index($frag[$i], ">") + 1) = "";
        if ( $i == 0 || ( $i == 1 && $frag[0] eq "" ) ) {
            $frag[$i] =~ s/^\n+//;
        }

        if ( $frag[$i] ) {
            if (! $psprint) {
                if ( $symbol ) {
                    $font_tag = 'sym';
                } elsif ( $preformat ) {
                    $font_tag = 'cour';
                } else {
                    $size = 0 if ($size < 0);
                    $size = 3 if ($size > 3);
                    $font_tag = $sizecode[$size];
                }
                $font_tag .= "bo" if ( $bold || $tbold );
                $font_tag .= "it" if ( $italic );
                @tags = ( $font_tag );
                if ( ! $preformat ) {
                    push (@tags, 'sup')     if ($sup);
                    push (@tags, 'sub')     if ($sub);
                    push (@tags, 'red')     if ($spanred);
                    push (@tags, $link_tag) if ($link);
                    if ( ! $intable ) {
                        push (@tags, "indent$indent$indent2") if ( $indent );
                        push (@tags, 'center') if ($center || $pcenter || $hcenter);
                    }
                }
                if (! $intable) {
                    $t->insert('end', $frag[$i], \@tags);
                } elsif ( $in_table_cell ) {
                    push (@tags, $justify);
                    $tcell->insert('end', $frag[$i], \@tags);
                }

            } else {
                if ($legend) {
                    $bold = 1;
                    $fontsize = 7;
                } else {
                    $fontsize = $ps_fontsize;
                }
                $ps_color = $normal_color;
                $ps_color = "red"       if ($spanred);
                $ps_color = $link_color if ($link);
                $ps_font  = sprintf(" %d", $fontsize);
                $ps_font  = sprintf(" %d", $fontsize * 1.5 ) if ($size >= 3);
                $ps_font  = sprintf(" %d", $fontsize * 1.25) if ($size == 2);
                $ps_font  = sprintf(" %d", $fontsize * 0.65) if ($size <= 0);
                $ps_font .= " symbol" if ($symbol);
                $ps_font .= " bold"   if ($bold || $tbold);
                $ps_font .= " italic" if ($italic);
                if ($legend) {
                    $ps_y += 0.75 * $fontsize if ($sub);
                    if ($ps_count == 0) {
                        &ps_text($sav_x, $ps_y, $frag[$i], 'w', $ps_font,
                             $legend, 'left', $ps_x - $sav_x, $wrapwidth, 0, 1);
                    } else {
                        &ps_text($sav_x, $ps_y, $frag[$i], 'w', $ps_font,
                             $legend, 'left', $ps_x - $sav_x, $wrapwidth, 1, 1);
                    }
                    $ps_y -= 0.75 * $fontsize if ($sub);
                } else {
                    $ps_y -= 0.75 * $fontsize if ($sub);
                    if ($ps_count == 0) {
                        &ps_text($sav_x, $ps_y, $frag[$i], 'nw', $ps_font,
                                 $ps_color, 'left', $ps_x - $sav_x, $wrapwidth);
                    } else {
                        &ps_text($sav_x, $ps_y, $frag[$i], 'nw', $ps_font,
                              $ps_color, 'left', $ps_x - $sav_x, $wrapwidth, 1);
                    }
                    $ps_y += 0.75 * $fontsize if ($sub);
                }
                $ps_count++;
            }
        }
        if (! $intable) {
            $j = -1;
            until ( index($frag[$i], "\n", $j+1) == -1 ) {
                $nchar += index($frag[$i], "\n", $j+1) - ($j+1);
                $longline = $nchar if ( $nchar > $longline );
                $nlines += 1 + int($nchar/$wrapwidth);
                $nchar = 0;
                $j = index($frag[$i], "\n", $j+1);
            }
            $nchar += length($frag[$i]) - ($j + 1);
            $longline = $nchar if ( $nchar > $longline );
        } elsif ( $in_table_cell ) {
            $j = -1;
            until ( index($frag[$i], "\n", $j+1) == -1 ) {
                $j = index($frag[$i], "\n", $j+1);
                push (@line_breaks, $cell_char + $j);
            }
            $cell_char += length($frag[$i]);
        }
    }
    if (! $psprint) { $t->configure(-state => 'disabled'); }
    $nlines += int($nchar/$wrapwidth);
    $longline = $wrapwidth if ( $longline > $wrapwidth );
    return $longline, $nlines;
}


sub configure_tags {
    my ($t) = @_;

    $t->tagConfigure('reg',      -font => 'default');
    $t->tagConfigure('regbo',    -font => 'bo');
    $t->tagConfigure('regit',    -font => 'it');
    $t->tagConfigure('regboit',  -font => 'boit');
    $t->tagConfigure('big',      -font => 'big');
    $t->tagConfigure('bigbo',    -font => 'bigbo');
    $t->tagConfigure('bigit',    -font => 'bigit');
    $t->tagConfigure('bigboit',  -font => 'bigboit');
    $t->tagConfigure('med',      -font => 'med');
    $t->tagConfigure('medbo',    -font => 'medbo');
    $t->tagConfigure('medit',    -font => 'medit');
    $t->tagConfigure('medboit',  -font => 'medboit');
    $t->tagConfigure('sm',       -font => 'sm');
    $t->tagConfigure('smbo',     -font => 'smbo');
    $t->tagConfigure('smit',     -font => 'smit');
    $t->tagConfigure('smboit',   -font => 'smboit');
    $t->tagConfigure('sym',      -font => 'sym');
    $t->tagConfigure('symbo',    -font => 'symbo');
    $t->tagConfigure('symit',    -font => 'symit');
    $t->tagConfigure('symboit',  -font => 'symboit');
    $t->tagConfigure('cour',     -font => 'cour');
    $t->tagConfigure('courbo',   -font => 'courbo');
    $t->tagConfigure('courit',   -font => 'courit');
    $t->tagConfigure('courboit', -font => 'courboit');

    $t->tagConfigure('sup',      -offset   => int(0.75*$default_font_size));
    $t->tagConfigure('sub',      -offset   => -int(0.25*$default_font_size));
    $t->tagConfigure('center',   -justify  => 'center');
    $t->tagConfigure('left',     -justify  => 'left');
    $t->tagConfigure('right',    -justify  => 'right');
    $t->tagConfigure('red',      -foreground => 'red');
    $t->tagConfigure('indent10', -lmargin1 => '0.5c', -lmargin2 => '0.5c');
    $t->tagConfigure('indent11', -lmargin1 => '0.5c', -lmargin2 => '1.0c');
    $t->tagConfigure('indent20', -lmargin1 => '1.0c', -lmargin2 => '1.0c');
    $t->tagConfigure('indent21', -lmargin1 => '1.0c', -lmargin2 => '1.5c');
    $t->tagConfigure('indent30', -lmargin1 => '1.5c', -lmargin2 => '1.5c');
    $t->tagConfigure('indent31', -lmargin1 => '1.5c', -lmargin2 => '2.0c');
}


sub configure_legend_tags {
    my ($t) = @_;

    $t->tagConfigure('reg',      -font => 'ldefault');
    $t->tagConfigure('regbo',    -font => 'lbo');
    $t->tagConfigure('regit',    -font => 'lit');
    $t->tagConfigure('regboit',  -font => 'lboit');
    $t->tagConfigure('big',      -font => 'lbig');
    $t->tagConfigure('bigbo',    -font => 'lbigbo');
    $t->tagConfigure('bigit',    -font => 'lbigit');
    $t->tagConfigure('bigboit',  -font => 'lbigboit');
    $t->tagConfigure('med',      -font => 'lmed');
    $t->tagConfigure('medbo',    -font => 'lmedbo');
    $t->tagConfigure('medit',    -font => 'lmedit');
    $t->tagConfigure('medboit',  -font => 'lmedboit');
    $t->tagConfigure('sm',       -font => 'lsm');
    $t->tagConfigure('smbo',     -font => 'lsmbo');
    $t->tagConfigure('smit',     -font => 'lsmit');
    $t->tagConfigure('smboit',   -font => 'lsmboit');
    $t->tagConfigure('sym',      -font => 'lsym');
    $t->tagConfigure('symbo',    -font => 'lsymbo');
    $t->tagConfigure('symit',    -font => 'lsymit');
    $t->tagConfigure('symboit',  -font => 'lsymboit');
    $t->tagConfigure('cour',     -font => 'lcour');
    $t->tagConfigure('courbo',   -font => 'lcourbo');
    $t->tagConfigure('courit',   -font => 'lcourit');
    $t->tagConfigure('courboit', -font => 'lcourboit');

    $t->tagConfigure('sup',      -offset   => int(0.75 * 7));
    $t->tagConfigure('sub',      -offset   => -int(0.25 * 7));
    $t->tagConfigure('center',   -justify  => 'center');
    $t->tagConfigure('left',     -justify  => 'left');
    $t->tagConfigure('right',    -justify  => 'right');
    $t->tagConfigure('red',      -foreground => 'red');
}


sub get_ops {
    my ($s) = @_;
    my %ops = ();
    my ($i, $key, $value);

    $s =~ s/^<\w+\s*//;                  # clip off the tag
    $s = substr($s, 0, index($s, ">"));  # clip off the end
    $s =~ s/\s+$//;                      # clip off dangling whitespace
    until ( $s eq "" ) {
        $i = index($s, "=");
        last if ( $i == -1 );
        $key = substr($s, 0, $i);
        substr($s, 0, $i+1) = "";
        if ( $s =~ /^\"/ ) {
            $i = index($s, "\"", 1);
            last if ( $i == -1 );
            $value = substr($s, 1, $i-1);
            substr($s, 0, $i+1) = "";
            $s =~ s/^\s+//;
        } else {
            $i = index($s, " ");
            if ( $i > -1 ) {
                $value = substr($s, 0, $i);
                substr($s, 0, $i+1) = "";
            } else {
                $value = $s;
                $s = "";
            }
        }
        $ops{$key} = $value;
    }

#   Input constraints:
    if ( $ops{'align'} ) {
        delete $ops{'align'}
          if ( &list_match(lc($ops{'align'}), qw/left right center/) == -1 );
    }
    if ( $ops{'rowspan'} ) {
        $ops{'rowspan'} = int($ops{'rowspan'});
        delete $ops{'rowspan'} if ( $ops{'rowspan'} <= 1 );
    }
    if ( $ops{'colspan'} ) {
        $ops{'colspan'} = int($ops{'colspan'});
        delete $ops{'colspan'} if ( $ops{'colspan'} <= 1 );
    }
    if ( $ops{'border'} ) {
        $ops{'border'} = int($ops{'border'});
        delete $ops{'border'} if ( $ops{'border'} < 0 );
    }
    if ( $ops{'cellpadding'} ) {
        $ops{'cellpadding'} = int($ops{'cellpadding'});
        delete $ops{'cellpadding'} if ( $ops{'cellpadding'} <= 0 );
    }
    if ( $ops{'cellspacing'} ) {
        $ops{'cellspacing'} = int($ops{'cellspacing'});
        delete $ops{'cellspacing'} if ( $ops{'cellspacing'} <= 0 );
    }
    if ( $ops{'width'} ) {
        $ops{'width'} = int($ops{'width'});
        delete $ops{'width'} if ( $ops{'width'} <= 0 );
    }
    if ( $ops{'height'} ) {
        $ops{'height'} = int($ops{'height'});
        delete $ops{'height'} if ( $ops{'height'} <= 0 );
    }
    return %ops;
}


sub follow_link {
    my ($link, $tw) = @_;
    my ($i, @kids, $kid, @grandkids, $gk, $spot, $linein, $content);
    my ($extension, $filetypes, $pid, $ProcessObj, $prog, $p);

    # Check for an internal hyperlink.
    if ( $link =~ /^#/ ) {
        if ( Exists($tw) ) {
            $link =~ s/^#//;
            $tw->see($link);
        }

    # Check for a link to the main page.
    } elsif ( $link eq "Alkalinity Calculator" ) {
        $main->deiconify();
        $main->raise();
        $main->focus;

    # Check for a hyperlink to an external site.  Start up a browser.
    #   The variable $browser is global so that it is remembered.
    } elsif ( $link =~ /^http:\/\// ) {
        if ( $^O eq 'MSWin32' || $^O eq 'cygwin' ) {
            if ( ! defined ( $browser ) ) {
                # $browser = 'C:\\Program Files\\Netscape\\Netscape\\Netscp.exe';
                $browser = 'C:\\Program Files\\Internet Explorer\\IEXPLORE.EXE';
            }
            $extension = ".exe";
            $filetypes = [ ['Program Files', '.exe'], ['All Files',  '*'] ];
        } else {
            if ( ! defined ( $browser ) ) {
                foreach $p ("/bin", "/usr/bin",
                            "/usr/local/bin", "/usr/opt/bin") {
                    if ( -e "${p}/netscape" ) {
                        $browser = "${p}/netscape";
                        $ENV{PATH} = $p;
                        last;
                    }
                }
            }
            $extension = "";
            $filetypes = [ ['All Files',  '*'] ];
        }
        if ( ! -e $browser ) {
            $browser = $main->getOpenFile(
                -title => "Find Browser Program",
                -defaultextension => $extension,
                -filetypes => $filetypes,
                );
        }
        if ( defined ( $browser ) ) {
            if ( $^O eq 'MSWin32' ) {
                $prog = substr($browser, rindex($browser, "\\")+1);
                $prog = substr($prog, 0, index($prog, "\."));
                Win32::Process::Create($ProcessObj,
                                       $browser, "$prog $link", 0,
                                       Win32::Process::DETACHED_PROCESS(), ".")
                           or &pop_up_error("Failed to spawn\n$browser");
            } else {
                if ( ($pid = fork) == 0 ) {
                    if ( $browser =~ /netscape/ ) {
                        exec ( "netscape -remote \"openURL($link,new-window)\" >> /dev/null 2>&1 || netscape $link" );
                    } else {
                        exec ( { $browser } (" ", $link) );
                    }
                    &pop_up_error("Failed to spawn\n$browser");
                    exit (1);
                }
            }
        } else {
            &pop_up_error("No Internet browser was identified.\n" .
                          "Cannot follow link.");
        }

    # Otherwise, follow a hyperlink to a local document.
    } else {

        # Split up the link, if necessary.

        if ( index($link, "#") > 0 ) {
            $i = index($link, "#");
            $spot = substr($link, $i+1);
            substr($link, $i) = "";
        }

        # Keep track of open windows in an array.
        # Determine when one is already open.

        $i = &list_match($link, @windowlist);
        if ( $i > -1 ) {
            if ( Exists($window[$i]) ) {
                $window[$i]->deiconify();
                $window[$i]->raise();
                $window[$i]->focus;
                if ( $spot ) {
                    @kids = $window[$i]->children;
                    foreach $kid (@kids) {
                        @grandkids = $kid->children;
                        $gk = &list_search("ROText", @grandkids);
                        last if ( $gk > -1 );
                    }
                    $grandkids[$gk]->see($spot) if ( $gk > -1 );
                }
            } else {
                undef $windowlist[$i];
                $i = -1;
            }
        }
        if ( $i == -1 ) {
            open (IN, $link) or return &pop_up_error("Unable to open\n$link");
            push (@windowlist, $link);
            $i = $#windowlist;
            $link =~ s/\.html$//;
            $link =~ s/_/ /g;
            $link = ucfirst($link);
            $main->Busy(-recurse => 1);
            $window[$i] = $main->Toplevel();
            $window[$i]->title($link);
            $window[$i]->minsize(350,250);
            $window[$i]->configure(-cursor => $cursor_shape);
            &footer($window[$i]);
            $tw = $window[$i]->Scrolled('ROText',
                -relief     => 'flat',
                -font       => 'default',
                -background => $background_color,
                -cursor     => $cursor_shape,
                -wrap       => 'word',
                -scrollbars => 'osoe',
                -height     => 30,
                )->pack(-fill => 'both', -expand => 1);

            if ( $link eq "Gpl" ) {
                $content = "";
                until (<IN> =~ /<\/head>/) {}
                while ( defined ($linein = <IN>) ) {
                    $content .= $linein;
                }
            } else {
                $content = "<img src=\"images/usgs.gif\" width=72 height=20>";
                until (<IN> =~ /includes\/owsc_header/) {}
                while ( defined ($linein = <IN>) ) {
                    last if ( $linein =~ /includes\/owsc_footer/ );
                    $content .= $linein;
                }
            }
            close (IN);
            &parse($tw, $content);
            $window[$i]->focus;
            $tw->see($spot) if ( $spot );
            $main->Unbusy;
        }
    }
}


sub about {
    my ($tw);

    if ( Exists($about_window) ) {
        $about_window->deiconify();
        $about_window->raise();
        $about_window->focus;
    } else {
        $about_window = $main->Toplevel();
        $about_window->title("About the Alkalinity Calculator");
        $about_window->minsize(350,200);
        $about_window->configure(-cursor => $cursor_shape);
        $tw = $about_window->Scrolled('ROText',
            -width      => '60',
            -height     => '18',
            -relief     => 'flat',
            -font       => 'default',
            -background => $background_color,
            -cursor     => $cursor_shape,
            -wrap       => 'word',
            -scrollbars => 'osoe',
            )->pack(-fill => 'both', -expand => 1);
        &parse($tw, "
          <img src=\"images/usgs.gif\" width=72 height=20>
          <h1>The Alkalinity Calculator</h1>
          <p><b>Version:</b> $version
          <br><b>Author:</b> Stewart A. Rounds &lt;sarounds\@usgs.gov&gt;
          <br>Copyright (c) 2003-2012</p>
          <p><b>Home page:</b> <a href=\"http://or.water.usgs.gov/alk/\">http://or.water.usgs.gov/alk/</a></p>
          <p>The Tk version of the Alkalinity Calculator was developed for
          the U.S. Geological Survey <i>for no fee and on my own time</i>.
          Send me an email if you like it!</p>
          <p>This version was written in Perl with the Tk toolkit and is
          free software; you may redistribute it and/or modify it under the
          terms of the <a href=\"gpl.html\">GNU General Public License</a>
          as published by the Free Software Foundation.  Terms of the license
          also may be found at 
          <a href=\"http://www.gnu.org/copyleft/gpl.html\">http://www.gnu.org/copyleft/gpl.html</a>.</p>
          ");
        $about_window->focus;
    }
}
