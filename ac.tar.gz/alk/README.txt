Alkalinity Calculator - Instructions for the Stand-Alone Version
================================================================

Version 2.22Tk // 22-Sep-2012

Find a home for the files from this package in a separate directory with
an appropriate name, like "alk" or "AC."

This stand-alone version of the Alkalinity Calculator works without Internet
access.  If you have Internet access, you can always use the online version
at http://or.water.usgs.gov/alk/; the functionality is identical, other
than the fact that you can save your input data a bit easier with the
stand-alone version.

This version of the Alkalinity Calculator runs from a set of Perl scripts.
If you are working on a Windows computer, the stand-alone version is supplied
as a self-extracting EXE file that contains its own Perl environment;
this makes things easy because you do NOT need to have Perl installed on
your computer and you don't have to worry about installing special Perl
modules that may or may not be part of a standard Perl distribution package.
Just fire up the self-extracting EXE file, and a Perl environment will be
created in your temporary space, running the Alkalinity Calculator inside
that space.  It's easy!

If you are working on a non-Windows machine, then you'll need to install Perl
on your computer and ensure that it contains the Tk module.  Without the
Tk module, the user interface for the stand-alone Alkalinity Calculator
will not work.  Perl may be obtained free of charge over the Internet.
Versions of Perl for a variety of platforms (Windows, Solaris, Linux) are
available from CPAN at http://www.cpan.org/.  Once Perl has been installed,
the Alkalinity Calculator is invoked by starting the "ac.pl" script.

If you have problems, send me an email at sarounds@usgs.gov.
Don't forget to sign up on the Alkalinity Calculator mailing list at
http://or.water.usgs.gov/alk/maillist.html.

-Stewart Rounds
 U.S. Geological Survey


############################################################################
#
#  The Alkalinity Calculator
#  Perl/Tk Version
#  Copyright (c) 2003-2012, Stewart A. Rounds
#
#  Contact:
#    Stewart A. Rounds
#    U.S. Geological Survey
#    2130 SW 5th Avenue
#    Portland, OR 97201
#    sarounds@usgs.gov
#  (I work for the U.S. Geological Survey, but this program was
#   developed on my own time.)
#
#  This program is free software; you may redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
############################################################################
