############################################################################
#
#  The Alkalinity Calculator
#  Perl/Tk Interface, PostScript Driver
#  Copyright (C) 2003-2012, Stewart A. Rounds
#
#  Contact:
#    Stewart A. Rounds
#    U.S. Geological Survey
#    2130 SW 5th Avenue
#    Portland, OR 97201
#    sarounds@usgs.gov
#  (I work for the U.S. Geological Survey, but this program was
#   developed on my own time.)
#
#  This program is free software; you may redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
############################################################################

# Turn on for debugging only.  Not needed for routine work.
#use strict;
#use warnings;
#use diagnostics;

# Declare the usage of some global variables.
our ($ps_xpagesize, $ps_ypagesize, $ps_rowheight, $ps_fontsize,
     $ps_margin, $ps_ingraph,
     $ps_x, $ps_y, $ps_col1, $ps_col2, $ps_rspan,
     @ps_droplines, %ps_twidth,
     @valid_colors, @valid_linetypes,
     $version, $normal_color, $link_color, $date_time,
     $site_name, $site_id, $collect_time, $collect_date,
    );

# Set aside some private variables.
my (%metrics, %helv_metrics, %helv_ital_metrics,
    %helv_bold_metrics, %helv_bold_ital_metrics, %symbol_metrics,
    $ps_fontscale, $ps_fontstring, $ps_linetype, $ps_linecolor,
    $ps_page, $ps_lasty, $ps_yg1, $ps_yg2, $ps_xg1, $ps_xg2,
   );

# Set page size for US letter, portrait orientation.
# Set margins, row height, font size, etc.
$ps_xpagesize    = 612;
$ps_ypagesize    = 792;
$ps_rowheight    = 12;
$ps_fontsize     = 9;
$ps_fontscale    = 1.0;
$ps_margin       = 60;
$ps_col1         = $ps_margin;
$ps_col2         = $ps_col1 + 110;
$ps_ingraph      = 0;
@valid_colors    = qw(white black red green blue cyan magenta ccccff);
@valid_linetypes = qw(solid dashed);
$ps_linecolor    = "black";
$ps_linetype     = "solid";
$ps_fontstring   = "/Helvetica 9.00";
@ps_droplines    = ();
$ps_rspan        = 0;

# Table style info.
%ps_twidth  = ("data",      [ 45,  50,  50,  60,  90],
               "results",   [136, 110, 136],
               "gran",      [ 21, 129, 103, 129],
               "constants", [ 80,  60,  60],
               "t_sc_i",    [125, 110],
              );

# Font metrics, just for helvetica (keeping it simple).
%helv_metrics = (
    " ",  191, "\!", 208, "\"", 305, "\#", 542, "\$", 518, "\%", 859,
    "\&", 637, "\`", 157, "\(", 291, "\)", 256, "*",  343, "+",  534,
    ",",  192, "-",  284, ".",  191, "/",  284, "0",  507, "1",  347,
    "2",  511, "3",  506, "4",  520, "5",  513, "6",  513, "7",  520,
    "8",  513, "9",  509, ":",  214, ";",  215, "<",  534, "=",  534,
    ">",  539, "?",  509, "@",  951, "A",  653, "B",  623, "C",  677,
    "D",  667, "E",  613, "F",  579, "G",  709, "H",  644, "I",  194,
    "J",  426, "K",  658, "L",  533, "M",  761, "N",  646, "O",  742,
    "P",  617, "Q",  742, "R",  679, "S",  621, "T",  593, "U",  645,
    "V",  645, "W",  929, "X",  649, "Y",  661, "Z",  583, "[",  250,
    "\\", 284, "]",  209, "_",  578, "'",  158, "a",  535, "b",  523,
    "c",  477, "d",  495, "e",  513, "f",  258, "g",  489, "h",  486,
    "i",  150, "j",  153, "k",  502, "l",  152, "m",  762, "n",  487,
    "o",  510, "p",  523, "q",  495, "r",  321, "s",  459, "t",  254,
    "u",  482, "v",  486, "w",  708, "x",  473, "y",  478, "z",  457,
    "{",  276, "|",  160, "}",  262, "~",  508,
              );

%helv_bold_metrics = (
    " ",  214, "\!", 262, "\"", 424, "\#", 553, "\$", 527, "\%", 863,
    "\&", 694, "\`", 201, "\(", 303, "\)", 285, "*",  357, "+",  533,
    ",",  214, "-",  298, ".",  214, "/",  275, "0",  517, "1",  378,
    "2",  515, "3",  516, "4",  522, "5",  517, "6",  519, "7",  528,
    "8",  525, "9",  516, ":",  263, ";",  263, "<",  529, "=",  534,
    ">",  529, "?",  556, "@",  947, "A",  703, "B",  666, "C",  685,
    "D",  681, "E",  624, "F",  586, "G",  711, "H",  657, "I",  213,
    "J",  486, "K",  717, "L",  579, "M",  776, "N",  661, "O",  742,
    "P",  633, "Q",  745, "R",  677, "S",  633, "T",  598, "U",  654,
    "V",  647, "W",  932, "X",  653, "Y",  650, "Z",  578, "[",  308,
    "\\", 289, "]",  260, "_",  578, "'",  202, "a",  524, "b",  575,
    "c",  522, "d",  545, "e",  525, "f",  313, "g",  541, "h",  541,
    "i",  207, "j",  210, "k",  548, "l",  207, "m",  824, "n",  546,
    "o",  569, "p",  574, "q",  544, "r",  370, "s",  520, "t",  301,
    "u",  541, "v",  536, "w",  766, "x",  535, "y",  538, "z",  468,
    "{",  317, "|",  180, "}",  352, "~",  519,
              );

%helv_ital_metrics = (
    " ",  213, "\!", 363, "\"", 455, "\#", 649, "\$", 613, "\%", 895,
    "\&", 644, "\`", 309, "\(", 446, "\)", 325, "*",  471, "+",  591,
    ",",  214, "-",  351, ".",  213, "/",  434, "0",  598, "1",  498,
    "2",  620, "3",  599, "4",  573, "5",  629, "6",  611, "7",  671,
    "8",  604, "9",  599, ":",  326, ";",  325, "<",  635, "=",  609,
    ">",  596, "?",  630, "@", 1036, "A",  653, "B",  711, "C",  770,
    "D",  759, "E",  751, "F",  734, "G",  809, "H",  799, "I",  349,
    "J",  581, "K",  813, "L",  551, "M",  916, "N",  801, "O",  828,
    "P",  733, "Q",  828, "R",  770, "S",  714, "T",  748, "U",  800,
    "V",  800, "W", 1084, "X",  794, "Y",  816, "Z",  737, "[",  405,
    "\\", 280, "]",  364, "_",  551, "'",  308, "a",  568, "b",  588,
    "c",  554, "d",  650, "e",  580, "f",  413, "g",  601, "h",  574,
    "i",  305, "j",  308, "k",  584, "l",  307, "m",  852, "n",  574,
    "o",  576, "p",  586, "q",  607, "r",  436, "s",  520, "t",  366,
    "u",  594, "v",  598, "w",  820, "x",  583, "y",  590, "z",  557,
    "{",  431, "|",  315, "}",  324, "~",  594,
              );

%helv_bold_ital_metrics = (
    " ",  245, "\!", 417, "\"", 579, "\#", 660, "\$", 628, "\%", 903,
    "\&", 720, "\`", 356, "\(", 458, "\)", 356, "*",  478, "+",  596,
    ",",  245, "-",  371, ".",  245, "/",  427, "0",  614, "1",  529,
    "2",  628, "3",  613, "4",  599, "5",  641, "6",  625, "7",  679,
    "8",  620, "9",  611, ":",  374, ";",  374, "<",  630, "=",  622,
    ">",  591, "?",  672, "@", 1032, "A",  703, "B",  762, "C",  793,
    "D",  776, "E",  762, "F",  741, "G",  819, "H",  812, "I",  368,
    "J",  641, "K",  843, "L",  606, "M",  931, "N",  816, "O",  828,
    "P",  747, "Q",  831, "R",  785, "S",  725, "T",  753, "U",  809,
    "V",  802, "W", 1087, "X",  802, "Y",  805, "Z",  733, "[",  463,
    "\\", 285, "]",  415, "_",  550, "'",  357, "a",  578, "b",  640,
    "c",  597, "d",  700, "e",  591, "f",  464, "g",  656, "h",  629,
    "i",  362, "j",  365, "k",  651, "l",  362, "m",  911, "n",  629,
    "o",  634, "p",  637, "q",  659, "r",  487, "s",  589, "t",  414,
    "u",  656, "v",  651, "w",  881, "x",  648, "y",  653, "z",  575,
    "{",  472, "|",  335, "}",  419, "~",  581,
              );

# Font metrics, for symbol font ("m" is for "mu").
%symbol_metrics = ( "m", 567 );


sub ps_header {
    $ps_page = 0;
    my $dtime = &get_datetime;

    print PSF << "end_of_input";
%!PS-Adobe-3.0
%%BoundingBox: 0 0 $ps_xpagesize $ps_ypagesize
%%LanguageLevel: 2
%%Creator: Alkalinity Calculator, version $version
%%CreationDate: $dtime
%%DocumentData: Clean8Bit
%%Orientation: Portrait
%%Pages: (atend)
%%PageOrder: Ascend
%%Title: Alkalinity Calculator Results: $site_name
%%For:
%%DocumentNeededResources: font Helvetica
%%+ font Helvetica-Bold
%%+ font Helvetica-Oblique
%%+ font Helvetica-BoldOblique
%%+ font Symbol
%%EndComments
%%BeginProlog
/m {moveto} def
/rm {rmoveto} def
/l {lineto} def
/s {stroke} def
/n {newpath} def
/c {closepath} def
/RL {rlineto} def
/SLW {setlinewidth} def
/GS {gsave} def
/GR {grestore} def
/SC {setcolor} def
/SD {setdash} def
/SLC {setlinecap} def
/SLJ {setlinejoin} def
/SCS {setcolorspace} def
/FFSF {exch findfont exch scalefont setfont} def
/JC {dup stringwidth pop -0.5 mul 0 rmoveto} def
/JR {dup stringwidth pop -1.0 mul 0 rmoveto} def
/CC {concat} def
/white   {1.0000 1.0000 1.0000} def
/black   {0.0000 0.0000 0.0000} def
/red     {1.0000 0.0000 0.0000} def
/green   {0.0000 1.0000 0.0000} def
/blue    {0.0000 0.0000 1.0000} def
/cyan    {0.0000 1.0000 1.0000} def
/magenta {1.0000 0.0000 1.0000} def
/ccccff  {0.8000 0.8000 1.0000} def
%%EndProlog
end_of_input

    &ps_newpage;
    $ps_y -= 20;
    print PSF << "end_of_input";
GS
/pix 216 string def
$ps_x $ps_y translate
72 20 scale
72 20 8
[72 0 0 -20 0 20]
{currentfile pix readhexstring pop}
false 3 colorimage

339966339966339966339966339966339966339966339966339966339966339966339966
339966339966339966339966339966339966ffffffffffffffffff339966339966339966
339966ffffffffffffffffffffffffffffff339966339966339966669999ffffffffffff
ffffff669999006666006666006666006666006666669999ffffffffffffffffffffffff
ffffffffffff669999006666006666006666006666336666669999ffffffffffffffffff
ffffffffffffffffff669999006666006666006666006666006666669999ffffffffffff

006666006666006666006666006666006666006666006666006666006666006666006666
006666006666006666006666006666006666ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffffffffff
006666006666006666006666006666006666006666006666006666ffffffffffffffffff
ffffff006666006666006666006666006666006666006666006666336666ffffffffffff
ffffff669999006666006666006666006666006666006666006666006666336666ffffff

006666006666006666006666006666006666006666006666006666006666006666006666
006666006666006666006666006666ffffffffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffff006666
006666006666006666006666006666006666006666006666006666669999ffffffffffff
006666006666006666006666006666006666006666006666006666006666339966ffffff
ffffff006666006666006666006666006666006666006666006666006666006666669999

006666006666006666006666006666006666006666006666006666006666006666006666
006666006666006666669999ffffffffffffffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff66999900666600666600666633996699cc99006666
006666006666006666ffffffffffff99cc99006666006666006666006666ffffff669999
006666006666006666339966ffffffffffffffffff006666006666006666006666ffffff
669999006666006666006666339966ffffffffffff669999006666006666006666339966

669999339966006666006666006666006666006666006666006666006666006666006666
006666006666ffffffffffff669999006666ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966669999006666
006666006666669999ffffffffffffffffff006666006666006666006666ffffff336666
006666006666006666ffffffffffffffffffffffff339966006666006666006666ffffff
339966006666006666006666669999ffffffffffffffffff006666006666006666006666

ffffffffffffffffff669999006666006666006666006666006666006666006666006666
669999ffffffffffff339966006666006666ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966669999006666
006666006666339966ffffffffffffffffff339966339966339966339966ffffff006666
006666006666006666ffffffffffffffffffffffff669999339966339966339966ffffff
339966006666006666006666669999ffffffffffffffffff339966339966339966339966

00666600666600666600666633666600666600666600666600666600666600666699cc99
ffffff669999006666006666339966ffffffffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff66999900666600666600666633996699cc99006666
00666600666600666699cc99ffffffffffffffffffffffffffffffffffffffffff006666
006666006666006666ffffffffffffffffffffffffffffffffffffffffffffffffffffff
669999006666006666006666006666ffffffffffffffffffffffffffffffffffffffffff

336666ffffffffffffffffffffffffffffff669999336666339966669999ffffffffffff
339966006666006666669999ffffffffffffffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffff006666
006666006666006666006666339966ffffffffffffffffffffffffffffffffffff006666
006666006666006666ffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffff006666006666006666006666006666669999ffffffffffffffffffffffffffffff

ffffffffffff33666600666600666633666699cc9999cc99ffffffffffff669999006666
006666339966ffffffffffff669999006666ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffff669999
006666006666006666006666006666006666669999ffffffffffffffffffffffff006666
006666006666006666ffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffff669999006666006666006666006666006666006666669999ffffffffffffffffff

669999006666006666669999ffffffffffffffffff99cc99339966006666006666006666
669999ffffffffffff006666006666336666ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffffffffff
669999006666006666006666006666006666006666006666ffffffffffffffffff006666
006666006666006666ffffffffffff339966006666006666006666006666006666669999
ffffffffffff669999006666006666006666006666006666006666336666ffffffffffff

006666006666ffffffffffff669999339966006666339966ffffffffffffffffffffffff
ffffff669999006666006666669999ffffffffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffffffffff
ffffffffffff336666006666006666006666006666006666006666ffffffffffff006666
006666006666006666ffffffffffff339966006666006666006666006666006666669999
ffffffffffffffffffffffff006666006666006666006666006666006666006666ffffff

339966ffffffffffff339966006666006666006666006666006666336666336666006666
006666006666336666ffffffffffff669999ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffffffffff
ffffffffffffffffff669999006666006666006666006666006666336666ffffff006666
006666006666006666ffffffffffff339966006666006666006666006666006666669999
ffffffffffffffffffffffffffffff669999006666006666006666006666006666669999

ffffff669999006666006666006666006666006666006666006666006666339966ffffff
ffffffffffffffffffffffff339966006666ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966ffffffffffff
ffffffffffffffffffffffffffffff33996600666600666600666600666699cc99006666
006666006666006666ffffffffffffffffffffffff669999006666006666006666669999
ffffffffffffffffffffffffffffffffffffffffff006666006666006666006666006666

339966006666006666006666006666006666006666006666006666006666006666006666
339966339966339966006666006666339966ffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666339966339966006666
006666006666ffffffffffffffffffffffff006666006666006666006666ffffff006666
006666006666006666ffffffffffffffffffffffff669999006666006666006666669999
006666006666006666006666ffffffffffffffffffffffff006666006666006666006666

006666006666006666006666006666006666006666006666006666006666006666006666
339966669999669999669999ffffffffffffffffffffffffffffff006666006666006666
006666ffffffffffffffffffffffff669999006666006666006666669999339966006666
006666006666ffffffffffffffffffffffff336666006666006666006666ffffff006666
006666006666006666ffffffffffffffffffffffff669999006666006666006666669999
006666006666006666006666ffffffffffffffffffffffff006666006666006666006666

006666006666006666006666006666006666006666006666006666006666006666006666
006666006666669999669999669999339966ffffffffffffffffff336666006666006666
006666669999ffffffffffffffffff006666006666006666006666ffffff339966006666
006666006666669999ffffffffffffffffff006666006666006666006666ffffff339966
006666006666006666669999ffffffffffffffffff669999006666006666006666669999
006666006666006666006666669999ffffffffffffffffff006666006666006666006666

006666006666006666006666006666006666006666006666006666006666006666006666
006666006666006666006666006666006666ffffffffffffffffff669999006666006666
006666006666339966339966006666006666006666006666006666ffffff99cc99006666
006666006666006666339966339966006666006666006666006666336666ffffffffffff
006666006666006666006666339966669999339966006666006666006666006666669999
669999006666006666006666006666339966339966006666006666006666006666669999

006666006666006666006666006666006666006666006666006666006666006666006666
006666006666006666006666006666006666ffffffffffffffffffffffff339966006666
006666006666006666006666006666006666006666006666ffffffffffffffffff006666
006666006666006666006666006666006666006666006666006666ffffffffffffffffff
339966006666006666006666006666006666006666006666006666006666006666669999
ffffff006666006666006666006666006666006666006666006666006666006666ffffff

006666006666006666006666006666006666006666006666006666006666006666006666
006666006666006666006666006666006666ffffffffffffffffffffffffffffff669999
006666006666006666006666006666006666336666ffffffffffffffffffffffffffffff
339966006666006666006666006666006666006666336666ffffffffffffffffffffffff
ffffff669999006666006666006666006666006666006666006666006666006666ffffff
ffffffffffff336666006666006666006666006666006666006666339966ffffffffffff

ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffff669999ffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffff669999ffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffff669999669999ffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffff669999ffffffffffffffffffffffffffffffffffff

GR
/Helvetica-Bold 16 FFSF
306 702 m
(Results of Alkalinity Calculator) JC show
/Helvetica-Bold 10 FFSF
$ps_col1 682 m
(Date:) show
/Helvetica 10 FFSF
( $date_time) show
$ps_col1 668 m
/Helvetica-Bold 10 FFSF
(Version:) show
/Helvetica 10 FFSF
( $version [) show
[/DeviceRGB] SCS
$link_color SC
(version history) show
[/DeviceRGB] SCS
black SC
(]) show
end_of_input
    $ps_x = $ps_col1;
    $ps_y = 664;
}


sub ps_footer {
    print PSF << "end_of_input";
showpage
%%Trailer
%%Pages: $ps_page
%%EOF
end_of_input
}


sub ps_newline {
    $ps_x  = $ps_col1;
    $ps_y -= $ps_rowheight;
    &ps_newpage if ($ps_y < $ps_margin);
}


sub ps_newpage {
    my ($ps_yy) = @_;
    my ($text, $fontstring, $i);
    $fontstring = $ps_fontstring;
    $ps_yy = $ps_margin if (! defined($ps_yy));

    if ($ps_page) {
        for ($i=0; $i<$#ps_droplines; $i+=2) {
            &ps_line($ps_droplines[$i], $ps_droplines[$i+1],
                     $ps_droplines[$i], $ps_yy, $normal_color, "solid");
        }
        if ($ps_rspan > 0) {
            @ps_droplines = ($ps_droplines[0], $ps_ypagesize - $ps_margin);
        } else {
            @ps_droplines = ();
        }
        print PSF "showpage\n";
    }
    $ps_page++;

    print PSF << "end_of_input";
%%Page: $ps_page $ps_page
1 SLW
0 SLC
0 SLJ
end_of_input

    $text  = $site_id;
    $text .= " -- " if ($text ne "");
    $text .= $site_name;
    if ($text ne "") {
        if ($collect_date ne "" || $collect_time ne "") {
            $text .= " (";
            $text .= $collect_date;
            $text .= ", " if ($collect_date ne "" && $collect_time ne "");
            $text .= $collect_time;
            $text .= ")";
        }
        &ps_text($ps_margin/3, $ps_margin/3, $text, 'sw', '7');
    }
    &ps_text($ps_xpagesize - $ps_margin/3, $ps_margin/3,
             "Page $ps_page", 'se', '7');
    &ps_text($ps_margin/3, $ps_ypagesize - $ps_margin/3,
             "Alkalinity Calculator", 'nw', '7');
    &ps_text($ps_xpagesize - $ps_margin/3, $ps_ypagesize - $ps_margin/3,
             "http://or.water.usgs.gov/alk/", 'ne', '7');

    $ps_fontstring = $fontstring;
    print PSF $ps_fontstring, " FFSF\n";
    $ps_x = $ps_col1;
    $ps_y = $ps_ypagesize - $ps_margin;
}


sub ps_setup_graph {
    my ($width, $height) = @_;

    &ps_newline;
    &ps_newpage if ($ps_y - $height * 0.7 < $ps_margin);

    $ps_x   = $ps_col2;
    $ps_xg1 = sprintf("%.2f", $ps_x);
    $ps_yg1 = sprintf("%.2f", $ps_y);
    $ps_xg2 = sprintf("%.2f", $ps_x + $width * 0.7);
    $ps_yg2 = sprintf("%.2f", $ps_y - $height * 0.7);
    $width  = sprintf("%.2f", $width);
    $height = sprintf("%.2f", $height);

#   Translate and scale.  Undo when graph is done.
    print PSF << "end_of_input";
GS
$ps_xg1 $ps_yg1 translate
0.7 -0.7 scale
end_of_input
    $ps_fontscale = 1.0/0.7;
    $ps_ingraph = 1;

#   Draw the extent of the graph canvas.  Give it a black border.
    &ps_rect(0, 0, $width, $height, "black");
}


sub ps_end_graph {

#   Unscale and untranslate.
    print PSF << "end_of_input";
GR
% 1.0 1.0 scale
% -$ps_xg1 -$ps_yg1 translate
end_of_input

    $ps_ingraph = 0;
    $ps_fontscale = 1.0;
    $ps_y = $ps_yg2;
}


sub ps_rect {
    my ($x1, $y1, $x2, $y2, $color) = @_;

    $x1 = sprintf("%.2f", $x1);
    $y1 = sprintf("%.2f", $y1);
    $x2 = sprintf("%.2f", $x2);
    $y2 = sprintf("%.2f", $y2);

    &ps_setlinetype($color, "solid");
    print PSF << "end_of_input";
n
$x1 $y1 m
$x1 $y2 l
$x2 $y2 l
$x2 $y1 l
c
s
end_of_input
}


sub ps_filled_rect {
    my ($x1, $y1, $x2, $y2, $color) = @_;

    $x1 = sprintf("%.2f", $x1);
    $y1 = sprintf("%.2f", $y1);
    $x2 = sprintf("%.2f", $x2);
    $y2 = sprintf("%.2f", $y2);

    &ps_setlinetype($color, "solid");
    print PSF << "end_of_input";
n
$x1 $y1 m
$x1 $y2 l
$x2 $y2 l
$x2 $y1 l
c
fill
end_of_input
}


sub ps_setlinetype {
    my ($color, $type) = @_;

    $color = lc($color);
    $color =~ s/[^a-z]//g;
    $type  = lc($type);

    $color = "black" if (&list_match($color, @valid_colors)    == -1);
    $type  = "solid" if (&list_match($type,  @valid_linetypes) == -1);

    if ($color ne $ps_linecolor) {
        print PSF "[/DeviceRGB] SCS\n$color SC\n";
        $ps_linecolor = $color;
    }
    if ($type ne $ps_linetype) {
        if ($type eq "dashed") {
            print PSF "[5 3] 0 SD\n";
        } else {
            print PSF "[] 0 SD\n";
        }
        $ps_linetype = $type;
    }
}


sub ps_line {
    my (@xy) = @_;
    my ($x, $y, $i, $type, $color);

#   Line type is optional last argument.
    $type = pop @xy;
    if (&list_match(lc($type), @valid_linetypes) == -1) {
        push (@xy, $type);
        undef $type;
    }

#   Line color is optional last or next-to-last argument.
    $color = pop @xy;
    if (&list_match(lc($color), @valid_colors) == -1) {
        push (@xy, $color);
        undef $color;
    }

    return if ($#xy < 3);
    &ps_setlinetype($color, $type);

    $x = sprintf("%.2f", $xy[0]);
    $y = sprintf("%.2f", $xy[1]);
    print PSF "n\n$x $y m\n";

    for ($i=2; $i<$#xy; $i+=2) {
        $x = sprintf("%.2f", $xy[$i]);
        $y = sprintf("%.2f", $xy[$i+1]);
        print PSF "$x $y l\n";
    }
    print PSF "s\n";
}


sub ps_polygon {
    my (@xy) = @_;
    my ($x, $y, $i, $type, $color);

#   Line type is optional last argument.
    $type = pop @xy;
    if (&list_match(lc($type), @valid_linetypes) == -1) {
        push (@xy, $type);
        undef $type;
    }

#   Line color is optional last or next-to-last argument.
    $color = pop @xy;
    if (&list_match(lc($color), @valid_colors) == -1) {
        push (@xy, $color);
        undef $color;
    }

    return if ($#xy < 3);
    &ps_setlinetype($color, $type);

    $x = sprintf("%.2f", $xy[0]);
    $y = sprintf("%.2f", $xy[1]);
    print PSF "n\n$x $y m\n";

    for ($i=2; $i<$#xy; $i+=2) {
        $x = sprintf("%.2f", $xy[$i]);
        $y = sprintf("%.2f", $xy[$i+1]);
        print PSF "$x $y l\n";
    }
    print PSF "c\ns\n";
}


sub ps_circle {
    my ($x, $y, $r, $color) = @_;

    $x = sprintf("%.2f", $x);
    $y = sprintf("%.2f", $y);
    $r = sprintf("%.2f", $r);

    &ps_setlinetype($color, "solid");
    print PSF << "end_of_input";
n
$x $y $r 0 360 arc
s
end_of_input
}


sub ps_text {
    my ($x, $y, $t,
        $anchor, $font, $color, $just, $indent, $width, $cont, $legend) = @_;

    my ($fontstring, $bold, $italic, $size, $center, $right, $i, $x2);
    my ($rside, $lside, $maxwidth, @lines);

    $anchor = "sw"                 if (! defined($anchor));
    $font   = "{Helvetica} 9 bold" if (! defined($font));
    $color  = "black"              if (! defined($color));
    $just   = "left"               if (! defined($just));
    $indent = 0                    if (! defined($indent));
    $width  = 0                    if (! defined($width));
    $width  = 10000                if ($ps_ingraph);
    $cont   = 0                    if (! defined($cont));
    $legend = 0                    if (! defined($legend));

    &ps_setlinetype($color, "solid");

    $bold   = $italic = 0;
    $bold   = 1 if (lc($font) =~ /bold/);
    $italic = 1 if (lc($font) =~ /italic/);
    $size   = $font;
    $size   =~ s/[^0-9]//g;

    if (lc($font) =~ /symbol/) {
        $fontstring = "/Symbol";
        %metrics    = %symbol_metrics;
    } elsif ($bold && $italic) {
        $fontstring = "/Helvetica-BoldOblique";
        %metrics    = %helv_bold_ital_metrics;
    } elsif ($bold) {
        $fontstring = "/Helvetica-Bold";
        %metrics    = %helv_bold_metrics;
    } elsif ($italic) {
        $fontstring = "/Helvetica-Oblique";
        %metrics    = %helv_ital_metrics;
    } else {
        $fontstring = "/Helvetica";
        %metrics    = %helv_metrics;
    }
    $fontstring .= sprintf(" %.2f", $size * $ps_fontscale);
    if ($fontstring ne $ps_fontstring) {
        print PSF $fontstring, " FFSF\n";
        $ps_fontstring = $fontstring;
    }

    if ($width == 0) {
        $rside = $ps_xpagesize - $ps_margin - $x;
        $lside = $x - $ps_margin;
        if (lc($anchor) =~ /e/) {            # e, ne, se
            $width = $lside;
        } elsif (lc($anchor) !~ /w/) {       # n, s
            if ($rside >= $lside) {
                $width = 2.0 * $lside;
            } else {
                $width = 2.0 * $rside;
            }
        } else {                             # w, nw, sw (default)
            $width = $rside;
        }
        $width = 72 if ($width < 0);
    }

    ($maxwidth, @lines) = &ps_text_metrics($t, $size * $ps_fontscale,
                                           $width, $indent);

    $center = 1 if ($just eq "center");
    $right  = 1 if ($just eq "right");
    $size *= -1 if ($ps_ingraph);

    if (lc($anchor) =~ /n/) {            # n, nw, ne
        $y -= $size * $ps_fontscale;

    } elsif (lc($anchor) !~ /s/) {       # e, w
        $y -= $size * $ps_fontscale / 2.2;
        $y += 1.33 * $size * $ps_fontscale * $#lines / 2.0;

    } else {                             # s, se, sw (default)
        $y += 1.33 * $size * $ps_fontscale * $#lines;
    }

    if (lc($anchor) =~ /e/) {            # e, ne, se
        $right  = 1 if ($#lines == 0);
        $center = 0 if ($#lines == 0);
        if ($right) {
            $x2 = $x;
        } elsif ($center) {
            $x2 = $x - $maxwidth / 2.0;
            $x  = $x2 + $indent / 2.0;
        } else {
            $x2 = $x - $maxwidth;
            $x  = $x2 + $indent;
        }

    } elsif (lc($anchor) !~ /w/) {       # n, s
        $right  = 0 if ($#lines == 0);
        $center = 1 if ($#lines == 0);
        if ($right) {
            $x += $maxwidth / 2.0;
            $x2 = $x;
        } elsif ($center) {
            $x2 = $x;
            $x += $indent / 2.0;
        } else {
            $x2 = $x - $maxwidth / 2.0;
            $x  = $x2 + $indent;
        }

    } else {                             # w, nw, sw (default)
        $right  = 0 if ($#lines == 0);
        $center = 0 if ($#lines == 0);
        if ($right) {
            $x += $maxwidth;
            $x2 = $x;
        } elsif ($center) {
            $x2 = $x + $maxwidth / 2.0;
            $x  = $x2 + $indent / 2.0;
        } else {
            $x2 = $x;
            $x += $indent;
        }
    }

    for ($i=0; $i<=$#lines; $i++) {
        $x = $x2 if ($i > 0);
        if ($i > 0 || ! $cont) {
            printf PSF "%.2f %.2f m\n", $x, $y;
        } elsif ($y != $ps_lasty) {
            printf PSF "0 %.2f rm\n", $y - $ps_lasty;
        }
        $ps_lasty = $y;
        if ($ps_ingraph) {
            print PSF "GS\n" if (! $legend);
            print PSF "[1 0 0 -1 0 0] CC\n";
        }
        $lines[$i]->{text} =~ s/\(/\\\(/g;
        $lines[$i]->{text} =~ s/\)/\\\)/g;
        print PSF "($lines[$i]->{text}) ";
        if ($center) {
            print PSF "JC ";
        } elsif ($right) {
            print PSF "JR ";
        }
        print PSF "show\n";
        if ($ps_ingraph) {
            if ($legend) {
                print PSF "[1 0 0 -1 0 0] CC\n";
            } else {
                print PSF "GR\n";
            }
        }
        if ($i < $#lines) {
            $y -= 1.33 * $size * $ps_fontscale;
            if ($y < $ps_margin && ! $ps_ingraph) {
                &ps_newpage($y + $size * $ps_fontscale);
                $y = $ps_y - $size * $ps_fontscale;
            }
        }
        if (! $ps_ingraph) {
            $ps_x = $x2 + $lines[$i]->{width} / 2.0 if ($center);
            $ps_x = $x2 + $lines[$i]->{width}       if (! $right && ! $center);
        }
    }
    if ($#lines && ! $ps_ingraph) {
        if (lc($anchor) =~ /n/) {
            $ps_y = $y + $size * $ps_fontscale;
        } else {
            $ps_y = $y;
        }
    }
}


sub ps_text_metrics {
    my ($t, $ptsize, $maxwidth, $indent) = @_;
    my (@lines, $maxw, @s, $i, $sum, $j, $len, $wrapj, $wraplen);

    @lines = split(/\n/, $t);
    $maxw = 0;
    for ($i=0; $i<=$#lines; $i++) {
        $wrapj = 0;
        $sum   = 0;
        $sum   = $indent if ($i==0);
        for ($j=0; $j<length($lines[$i]); $j++) {
            $t   = substr($lines[$i],$j,1);
            $len = $metrics{$t};
            $len = $metrics{"n"} if ($len == 0);
            $len = $helv_metrics{"n"} if ($len == 0);
            $sum += ($len + 55) * $ptsize / 1000;     # 55 is estimate
            if (! $ps_ingraph) {
                if ($sum <= $maxwidth) {
                    if ($t eq " " || $t eq "-") {
                        $wrapj   = $j+1;
                        $wraplen = $sum;
                    }
                } elsif ($wrapj > 0) {
                    $t = substr($lines[$i],$wrapj);
                    splice(@lines,$i+1,0,$t);
                    $lines[$i] = substr($lines[$i],0,$wrapj);
                    $sum = $wraplen;
                    last;
                } else {
                    splice(@lines,$i+1,0,$lines[$i]);
                    $lines[$i] = "";
                    $sum = 0;
                    last;
                }
            }
        }
        $s[$i]->{text}  = $lines[$i];
        $s[$i]->{width} = $sum;
        $maxw = $s[$i]->{width} if ($s[$i]->{width} > $maxw);
    }
    return ($maxw, @s);
}


sub ps_text_length {
    my ($text, $fontsize, $width) = @_;
    my ($bold, $italic, $t, $insert, $i, $add, $maxwidth);

    $bold = $italic = 0;
    $bold   = 1 if ($text =~ /<b>/ || $text =~ /<strong>/);
    $italic = 1 if ($text =~ /<i>/ || $text =~ /<em>/ || $text =~ /<var>/);
    if ($bold && $italic) {
        %metrics = %helv_bold_ital_metrics;
    } elsif ($bold) {
        %metrics = %helv_bold_metrics;
    } elsif ($italic) {
        %metrics = %helv_ital_metrics;
    } else {
        %metrics = %helv_metrics;
    }
    $text   =~ s/<br>/\n/g;
    $text   =~ s/<p>/\n\n/g;
    $t      = "";
    $insert = 1;
    for ($i=0; $i<length($text); $i++) {
        $add = substr($text,$i,1);
        if ($add eq "<") {
            $insert = 0;
        } elsif ($add eq ">") {
            $insert = 1;
        } elsif ($insert) {
            $t .= $add;
        }
    }
    $t =~ s/^\s+//;
    $t =~ s/\s+$//;
    $t =~ s/\s+/ /g;
    $t =~ s/\&uuml\;/u/g;
    $t =~ s/\&quot\;/\"/g;
    $t =~ s/\&amp\;/\&/g;
    $t =~ s/\&gt\;/\>/g;
    $t =~ s/\&lt\;/\</g;
    $t =~ s/\&micro\;/u/g;
    $t =~ s/\&nbsp\;/ /g;
    ($maxwidth, undef) = &ps_text_metrics($t, $fontsize, $width, 0);

    return $maxwidth;
}

1;
